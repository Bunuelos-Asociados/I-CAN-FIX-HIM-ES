﻿
translate spanish strings:

    # game/screens.rpy:249
    old "History"
    new "Historial"

    # game/screens.rpy:250
    old "Skip"
    new "Saltar"

    # game/screens.rpy:251
    old "Auto"
    new "Auto"

    # game/screens.rpy:252
    old "Save"
    new "Guardar"

    # game/screens.rpy:253
    old "Q.Save"
    new "Guardar.R"

    # game/screens.rpy:254
    old "Q.Load"
    new "Cargar.R"

    # game/screens.rpy:255
    old "Prefs"
    new "Prefs"

    # game/screens.rpy:305
    old "Start"
    new "Empezar"

    # game/screens.rpy:317
    old "Load"
    new "Cargar"

    # game/screens.rpy:323
    old "Preferences"
    new "Preferencias"

    # game/screens.rpy:329
    old "End Replay"
    new "Finalizar Replay"

    # game/screens.rpy:333
    old "Main Menu"
    new "Menú Principal"

    # game/screens.rpy:337
    old "About"
    new "Acerca de"

    # game/screens.rpy:346
    old "Help"
    new "Ayuda"

    # game/screens.rpy:356
    old "Quit"
    new "Salir"

    # game/screens.rpy:580
    old "Return"
    new "Volver"

    # game/screens.rpy:664
    old "Version [config.version!t]\n"
    new "Versión [config.version!t]\n"

    # game/screens.rpy:670
    old "Made by {a=https://bsky.app/profile/meowdynio.bsky.social}Meowdy_nio{/a}"
    new "Hecho por {a=https://bsky.app/profile/meowdynio.bsky.social}Meowdy_nio{/a}"

    # game/screens.rpy:671
    old "Messaging system base by {a=https://nighten.itch.io/renpy-simple-messaging-system-for-mobile-game}Nighten{/a}"
    new "Base del sistema de mensajes hecho por {a=https://nighten.itch.io/renpy-simple-messaging-system-for-mobile-game}Nighten{/a}"

    # game/screens.rpy:672
    old "Made with {a=https://www.renpy.org/}Ren'Py{/a} [renpy.version_only].\n\n[renpy.license!t]"
    new "Hecho con {a=https://www.renpy.org/}Ren'Py{/a} [renpy.version_only].\n\n[renpy.license!t]"

    # game/screens.rpy:708
    old "Page {}"
    new "Página {}"

    # game/screens.rpy:708
    old "Automatic saves"
    new "Guardado automático"

    # game/screens.rpy:708
    old "Quick saves"
    new "Guardado rápido"

    # game/screens.rpy:750
    old "{#file_time}%A, %B %d %Y, %H:%M"
    new "{#file_time}%A, %B %d %Y, %H:%M"

    # game/screens.rpy:750
    old "empty slot"
    new "ranura vacia"

    # game/screens.rpy:770
    old "<"
    new "<"

    # game/screens.rpy:774
    old "{#auto_page}A"
    new "{#auto_page}A"

    # game/screens.rpy:777
    old "{#quick_page}Q"
    new "{#quick_page}Q"

    # game/screens.rpy:783
    old ">"
    new ">"

    # game/screens.rpy:788
    old "Upload Sync"
    new "Upload Sync"

    # game/screens.rpy:792
    old "Download Sync"
    new "Download Sync"

    # game/screens.rpy:852
    old "Display"
    new "Pantalla"

    # game/screens.rpy:853
    old "Window"
    new "Ventana"

    # game/screens.rpy:854
    old "Fullscreen"
    new "Pantalla completa"

    # game/screens.rpy:859
    old "Unseen Text"
    new "Texto no visto"

    # game/screens.rpy:860
    old "After Choices"
    new "Tras opciones"

    # game/screens.rpy:861
    old "Transitions"
    new "Transiciones"

    # game/screens.rpy:874
    old "Text Speed"
    new "Veloc. del texto"

    # game/screens.rpy:878
    old "Auto-Forward Time"
    new "Veloc. auto-avance"

    # game/screens.rpy:885
    old "Music Volume"
    new "Volumen música"

    # game/screens.rpy:892
    old "Sound Volume"
    new "Volumen sonido"

    # game/screens.rpy:898
    old "Test"
    new "Test"

    # game/screens.rpy:902
    old "Voice Volume"
    new "Volumen voz"

    # game/screens.rpy:913
    old "Mute All"
    new "Silenciar todo"

    # game/screens.rpy:1032
    old "The dialogue history is empty."
    new "El historial de dialogo está vacío."

    # game/screens.rpy:1100
    old "Keyboard"
    new "Teclado"

    # game/screens.rpy:1101
    old "Mouse"
    new "Ratón"

    # game/screens.rpy:1104
    old "Gamepad"
    new "Mando"

    # game/screens.rpy:1117
    old "Enter"
    new "Enter"

    # game/screens.rpy:1118
    old "Advances dialogue and activates the interface."
    new ""

    # game/screens.rpy:1121
    old "Space"
    new ""

    # game/screens.rpy:1122
    old "Advances dialogue without selecting choices."
    new "Avanza el dilogo sin seleccionar opciones."

    # game/screens.rpy:1125
    old "Arrow Keys"
    new "Teclas de flecha"

    # game/screens.rpy:1126
    old "Navigate the interface."
    new "Navega la interfaz."

    # game/screens.rpy:1129
    old "Escape"
    new "Escape"

    # game/screens.rpy:1130
    old "Accesses the game menu."
    new "Accede al menú del juego."

    # game/screens.rpy:1133
    old "Ctrl"
    new "Ctrl"

    # game/screens.rpy:1134
    old "Skips dialogue while held down."
    new "Salta el diálogo mientras se presiona."

    # game/screens.rpy:1137
    old "Tab"
    new "Tabulador"

    # game/screens.rpy:1138
    old "Toggles dialogue skipping."
    new "Activa/desactiva el salto de diálogo."

    # game/screens.rpy:1141
    old "Page Down"
    new "Page Down"

    # game/screens.rpy:1142
    old "Rolls forward to later dialogue."
    new "Avanza hacia el diálogo siguiente."

    # game/screens.rpy:1146
    old "Hides the user interface."
    new "Oculta la interfaz."

    # game/screens.rpy:1150
    old "Takes a screenshot."
    new "Captura la pantalla."

    # game/screens.rpy:1154
    old "Toggles assistive {a=https://www.renpy.org/l/voicing}self-voicing{/a}."
    new "Activa/desactiva la asistencia por {a=https://www.renpy.org/l/voicing}voz-automática{/a}"

    # game/screens.rpy:1158
    old "Opens the accessibility menu."
    new "Abre el menú de accesibilidad."

    # game/screens.rpy:1164
    old "Left Click"
    new "Clic izquierdo"

    # game/screens.rpy:1168
    old "Middle Click"
    new "Clic medio"

    # game/screens.rpy:1172
    old "Right Click"
    new "Clic derecho"

    # game/screens.rpy:1176
    old "Mouse Wheel Down"
    new "Rueda del ratón abajo"

    # game/screens.rpy:1183
    old "Right Trigger\nA/Bottom Button"
    new "Gatillo derecho\nA/Botón inferior"

    # game/screens.rpy:1187
    old "Right Shoulder"
    new "R1/RB"

    # game/screens.rpy:1191
    old "D-Pad, Sticks"
    new "Cruceta, Joysticks"

    # game/screens.rpy:1195
    old "Start, Guide, B/Right Button"
    new "Comenzar, Guía, B/Botón derecho"

    # game/screens.rpy:1199
    old "Y/Top Button"
    new "Y/Botón arriba"

    # game/screens.rpy:1202
    old "Calibrate"
    new "Calibrar"

    # game/screens.rpy:1267
    old "Yes"
    new "Sí"

    # game/screens.rpy:1268
    old "No"
    new "No"

    # game/screens.rpy:1314
    old "Skipping"
    new "Saltar"

    # game/screens.rpy:1644
    old "Menu"
    new "Menú"

    # game/screens.rpy:868
    old "Language"
    new "Idioma"

    # game/screens.rpy:869
    old "English"
    new "Inglés"

    # game/screens.rpy:873
    old "Spanish"
    new "Español"

