﻿
# game/actions.rpy:9
translate spanish send_to_work_51d1a823:

    # mf "NOOO DON'T MAKE ME GET A JOB I BEG YOU!!!!![cat]"
    mf "¡¡¡¡¡NOOO, NO ME HAGAS BUSCAR EMPLEO, TE LO SUPLICO!!!!![cat]"

# game/actions.rpy:14
translate spanish send_to_work_51d1a823_1:

    # mf "NOOO DON'T MAKE ME GET A JOB I BEG YOU!!!!![cat]"
    mf "¡¡¡¡¡NOOO, NO ME HAGAS BUSCAR EMPLEO, TE LO SUPLICO!!!!![cat]"

# game/actions.rpy:18
translate spanish send_to_work_fc553355:

    # mf "Okay... Let's get some cash![cat]"
    mf "Vale... ¡Hora de conseguir algún dinerillo![cat]"

# game/actions.rpy:32
translate spanish send_to_work_0d4c1970:

    # mf "I GOT A RAISE AND A BONUS!! YIPPE!!![cat]"
    mf "¡¡HE CONSEGUIDO UN ASCENSO Y UN BONUS!! ¡¡¡CHACHI!!![cat]"

# game/actions.rpy:54
translate spanish send_to_gym_88d2a3e6:

    # mf "I DON'T WANNA GO NOW!!!!![cat]"
    mf "¡¡¡¡¡NO QUIERO IR AHORA!!!!![cat]"

# game/actions.rpy:56
translate spanish send_to_gym_5d036979:

    # mf "I-I mean... I'm so tired now...[cat]"
    mf "E-Es decir... Estoy muy cansadito ahora mismo...[cat]"

# game/actions.rpy:59
translate spanish send_to_gym_74f1e969:

    # mf "I DON'T HAVE ENOUGH MONEY TO GO TO THE GYM NOW!!!![cat]"
    mf "¡¡¡¡NO TENGO SUFICIENTE DINERO PARA IR AL GIMNASIO AHORA!!!![cat]"

# game/actions.rpy:63
translate spanish send_to_gym_55016db8:

    # mf "It's too late to go there now...[cat]"
    mf "Es demasiado tarde para ir allí ahora...[cat]"

# game/actions.rpy:66
translate spanish send_to_gym_4f183ed3:

    # mf "Okay! Time to hit the gym![cat]"
    mf "¡Vale! ¡Hora de ponerse cachas![cat]"

# game/actions.rpy:88
translate spanish send_to_podcast_8be2c90d:

    # mf "MAN I REALIZED HOW FUCKED UP THOSE PODCASTS ARE!![cat]"
    mf "¡¡ME HE DADO CUENTA DE LO JODIDOS QUE SON ESOS PODCASTS EN REALIDAD!![cat]"

# game/actions.rpy:89
translate spanish send_to_podcast_ae45f91c:

    # mf "DON'T MAKE ME LISTEN TO THAT, THEY'RE GROSS!!![cat]"
    mf "¡¡¡NO ME HAGAS ESCUCHARLOS, ME DAN ASQUITO!!![cat]"

# game/actions.rpy:93
translate spanish send_to_podcast_f6947aad:

    # mf "MAN, I DON'T HAVE ENOUGH ENERGY TO LISTEN TO ANYONE HATE ON WOMEN AND MINORITIEEESS!![cat]"
    mf "¡¡NO TENGO SUFICIENTES ENERGIAS PARA ESCUCHAR A GENTE ODIAR A MUJERES Y A MINORIAAAAAAS!![cat]"

# game/actions.rpy:97
translate spanish send_to_podcast_55016db8:

    # mf "It's too late to go there now...[cat]"
    mf "Es demasiado tarde para ir allí ahora...[cat]"

# game/actions.rpy:100
translate spanish send_to_podcast_b6a51a60:

    # mf "Okay... Let's hear some hateful podcasts online![cat]"
    mf "Vale... ¡Escuchemos podcasts odiosos online![cat]"

# game/actions.rpy:114
translate spanish send_to_salon_fe8811aa:

    # mf "I'M TOO TIRED FOR A MAKEOVER!![cat]"
    mf "¡¡ESTOY DEMASIADO CANSADO PARA IR A LA PELU!![cat]"

# game/actions.rpy:119
translate spanish send_to_salon_713999ba:

    # mf "I CAN'T GO TO THE SALON WITHOUT MONEY!![cat]"
    mf "¡¡NO PUEDO IR A LA PELUQUERÍA SIN DINERO!![cat]"

# game/actions.rpy:120
translate spanish send_to_salon_f8b71262:

    # mf "THEY MIGHT MAKE ME BALD AND USE MY HAIR FOR WIGS!!!![cat]"
    mf "¡¡¡¡ME DEJARÁN CALVO Y USARAN MI PELO PARA PELUCAS!!!![cat]"

# game/actions.rpy:124
translate spanish send_to_salon_55016db8:

    # mf "It's too late to go there now...[cat]"
    mf "Es demasiado tarde para ir allí ahora...[cat]"

# game/actions.rpy:128
translate spanish send_to_salon_73f8c116:

    # mf "Let's go to the salon to look cute![cat]"
    mf "¡Vamos a la pelu para estar cucos y coquetos![cat]"

# game/actions.rpy:130
translate spanish send_to_salon_400007d9:

    # mf "I-I mean.. AWESOME, yes, to look awesome.[cat]"
    mf "Q-Quiero decir... FRESCOS, si, para estar bien frescos.[cat]"

# game/actions.rpy:148
translate spanish send_to_club_729a3768:

    # mf "I'M TOO TIRED TO GO TO THE CLUB!![cat]"
    mf "¡¡ESTOY DEMASIADO CANSADO PARA IR AL CLUB!![cat]"

# game/actions.rpy:153
translate spanish send_to_club_e14b5f50:

    # mf "I CAN'T GO TO THE CLUB WITHOUT MONEY!![cat]"
    mf "¡¡NO PUEDO IR AL CLUB SIN DINERO SUFICIENTE!![cat]"

# game/actions.rpy:154
translate spanish send_to_club_8da8e7c0:

    # mf "EVERYONE WILL LAUGH AT ME!!!!!![cat]"
    mf "¡¡¡¡¡¡TODOS SE DESCOJONARAN DE MI!!!!!![cat]"

# game/actions.rpy:158
translate spanish send_to_club_55016db8:

    # mf "It's too late to go there now...[cat]"
    mf "Es demasiado tarde para ir allí ahora...[cat]"

# game/actions.rpy:162
translate spanish send_to_club_1d318eeb:

    # mf "Let's go to the club and make friends! Yay!![cat]"
    mf "¡Vamos al club a hacer amiguetes! ¡¡Yay!![cat]"

# game/actions.rpy:164
translate spanish send_to_club_11236551:

    # mf "I-I mean.. L-let's go to the club to get some bitches, bro...[cat]"
    mf "E-Es decir... Vamos al club a agenciarnos unas buenas chorbas, bro...[cat]"

# game/actions.rpy:180
translate spanish send_to_library_98edfdf4:

    # mf "I'M TOO TIRED TO READ ANYTHING, MY BRAIN MELTED!![cat]"
    mf "¡ESTOY DEMASIADO CANSADO PARA LEER NADA, MI CEREBRO ES PAPILLA![cat]"

# game/actions.rpy:184
translate spanish send_to_library_55016db8:

    # mf "It's too late to go there now...[cat]"
    mf "Es demasiado tarde para ir allí ahora...[cat]"

# game/actions.rpy:189
translate spanish send_to_library_a7e1697b:

    # mf "Let's go read some books!! Yay!![cat]"
    mf "¡¡Vamos a leer unos libritos!! ¡¡Yay!![cat]"

# game/actions.rpy:208
translate spanish send_to_danger_feaba9c7:

    # mf "I'M TOO TIRED TO GO THERE RIGHT NOW!![cat]"
    mf "¡¡ESTOY DEMASIADO CANSADO PARA IR ALLÍ AHORA MISMO!![cat]"

# game/actions.rpy:213
translate spanish send_to_danger_01012cc5:

    # mf "THAT PLACE IS SCARY!![cat]"
    mf "ESE SITIO ACOJONA!![cat]"

# game/actions.rpy:214
translate spanish send_to_danger_5cd73b58:

    # mf "I DON'T FEEL CONFIDENT ENOUGH TO GO THERE!!![cat]"
    mf "¡¡¡NO TENGO LA CONFIANZA SUFICIENTE PARA IR ALLÍ AHORA MISMO!!![cat]"

# game/actions.rpy:218
translate spanish send_to_danger_55016db8:

    # mf "It's too late to go there now...[cat]"
    mf "Es demasiado tarde para ir allí ahora...[cat]"

# game/actions.rpy:224
translate spanish send_to_danger_d08b06ce:

    # mf "Let's go get in danger on purpose!! Yay!![cat]"
    mf "¡¡Vamos a ponernos en peligro a propósito!! ¡¡Yay!![cat]"

