﻿
translate spanish strings:

    # game/chatroom_screen.rpy:181
    old "Coach Hub"
    new "Coach Hub"

    # game/chatroom_screen.rpy:217
    old "Themes"
    new "Temas"

    # game/chatroom_screen.rpy:473
    old "Select your theme"
    new "Selecciona tu tema"

    # game/chatroom_screen.rpy:482
    old "Basic"
    new "Básico"

    # game/chatroom_screen.rpy:488
    old "Dark"
    new "Oscuro"

    # game/chatroom_screen.rpy:494
    old "Pastel"
    new "Pastel"

    # game/chatroom_screen.rpy:500
    old "Green"
    new "Verde"

    # game/chatroom_screen.rpy:506
    old "Ocean"
    new "Océano"

    # game/chatroom_screen.rpy:512
    old "Snow"
    new "Nieve"

    # game/chatroom_screen.rpy:518
    old "Pilk"
    new "Pilk"

    # game/chatroom_screen.rpy:527
    old "Close"
    new "Cerrar"

