﻿
translate spanish strings:

    # game/options.rpy:15
    old "I Can Fix Him!"
    new "I Can Fix Him!"

