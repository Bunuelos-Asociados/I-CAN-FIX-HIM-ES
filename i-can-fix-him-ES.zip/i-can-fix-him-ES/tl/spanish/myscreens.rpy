﻿
translate spanish strings:

    # game/myscreens.rpy:12
    old "Money: [inventory.money]"
    new "Dinero: [inventory.money]"

    # game/myscreens.rpy:25
    old "ITEMS"
    new "ITEMS"

    # game/myscreens.rpy:53
    old "Back"
    new "Atrás"

    # game/myscreens.rpy:64
    old "DESCRIPTION"
    new "DESCRIPCIÓN"

    # game/myscreens.rpy:90
    old "Buy"
    new "Comprar"

    # game/myscreens.rpy:216
    old "Use"
    new "Usar"

    # game/myscreens.rpy:267
    old "Day [current_day]"
    new "Día [current_day]"

    # game/myscreens.rpy:268
    old "Hours Remaining: [player.hours]"
    new "Horas Restantes: [player.hours]"

    # game/myscreens.rpy:277
    old "STAMINA: [player.stamina]"
    new "ESTAMINA: [player.stamina]"

    # game/myscreens.rpy:281
    old "CONFIDENCE: [player.confidence]"
    new "CONFIANZA: [player.confidence]"

    # game/myscreens.rpy:285
    old "STRENGTH: [player.strength]"
    new "FUERZA: [player.strength]"

    # game/myscreens.rpy:289
    old "INTELLIGENCE: [player.intelligence]"
    new "INTELIGENCIA: [player.intelligence]"

    # game/myscreens.rpy:293
    old "CHARM: [player.charm]"
    new "ENCANTO: [player.charm]"

    # game/myscreens.rpy:297
    old "GUTS: [player.guts]"
    new "AGALLAS: [player.guts]"

    # game/myscreens.rpy:301
    old "HATEFULNESS: [player.hatefulness]"
    new "ODIO: [player.hatefulness]"

    # game/myscreens.rpy:313
    old "END DAY"
    new "FINALIZAR EL DIA"

    # game/myscreens.rpy:319
    old "SHOP"
    new "TIENDA"

    # game/myscreens.rpy:324
    old "INVENTORY"
    new "INVENTARIO"

    # game/myscreens.rpy:329
    old "GO OUTSIDE"
    new "IR AFUERA"

    # game/myscreens.rpy:334
    old "LISTEN TO PODCASTS"
    new "ESCUCHAR PODCASTS"

    # game/myscreens.rpy:339
    old "TALK"
    new "CHARLAR"

    # game/myscreens.rpy:343
    old "MONEY [inventory.money]$"
    new "DINERO [inventory.money]$"

    # game/myscreens.rpy:354
    old "CITY MAP"
    new "MAPA DE LA CIUDAD"

    # game/myscreens.rpy:386
    old "Increase your charm and \nreduce your hatefulness here! \nHours: [salon_cost['hours']] \nCost: [salon_cost['money']]$"
    new "¡Aumenta tu encanto \ny reduce tu odio aquí! \nHoras: [salon_cost['hours']] \nCosto: [salon_cost['money']]$"

    # game/myscreens.rpy:394
    old "Increase your confidence here! \nHours: [club_cost['hours']] \nCost: [club_cost['money']]$"
    new "¡Aumenta tu confianza aquí! \nHoras: [club_cost['hours']] \nCosto: [club_cost['money']]$"

    # game/myscreens.rpy:402
    old "Increase your strength here! \nHours: [gym_cost['hours']] \nCost: [gym_cost['money']]$"
    new "¡Aumenta tu fuerza aquí! \nHoras: [gym_cost['hours']] \nCosto: [gym_cost['money']]$"

    # game/myscreens.rpy:411
    old "Increase your intelligence and \nreduce your hatefulness here!\nHours: [library_cost['hours']]"
    new "¡Aumenta tu inteligencia y reduce tu odio aquí!\nHoras: [library_cost['hours']]"

    # game/myscreens.rpy:420
    old "Earn cash here! \nHours: [current_work_data['work_hours']] \nEarn: [current_work_data['earn']]$"
    new "¡Gana dinero aquí! \nHoras: [current_work_data['work_hours']] \nGana: [current_work_data['earn']]$"

    # game/myscreens.rpy:429
    old "Increase your guts here! \nHours: [danger_cost['hours']]"
    new "¡Aumenta tus agallas aquí! \nHoras: [danger_cost['hours']]"

    # game/myscreens.rpy:316
    old "End this day and skip to the next one?"
    new "¿Terminar este día y pasar al siguiente?"

