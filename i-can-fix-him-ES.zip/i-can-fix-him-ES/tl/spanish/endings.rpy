﻿
# game/endings.rpy:5
translate spanish ending_64fe00df:

    # centered "A few months later..."
    centered "Unos meses después..."

# game/endings.rpy:8
translate spanish ending_b7cd4fb9:

    # mc "Thanks to that gig I managed to pay my debt."
    mc "Gracias a ese trabajillo conseguí pagar mi deuda."

# game/endings.rpy:9
translate spanish ending_0c333f59:

    # mc "Now I'm a free man."
    mc "Ahora soy un hombre libre."

# game/endings.rpy:10
translate spanish ending_46ae164c:

    # mc "I wonder how he's doing right now..."
    mc "Me pregunto cómo le irá ahora mismo..."

# game/endings.rpy:12
translate spanish ending_c374f8ba:

    # mc "Honestly, I can't take him out of my head..."
    mc "Honestamente, no puedo sacarle de mi cabeza..."

# game/endings.rpy:13
translate spanish ending_134cd35e:

    # mc "What in the world is wrong with me?"
    mc "¿Que cojones me pasa?"

# game/endings.rpy:15
translate spanish ending_28ff3180:

    # mc "I hope he's been okay this whole time."
    mc "Espero que haya estado bien todo este tiempo."

# game/endings.rpy:17
translate spanish ending_4d42edce:

    # mc "I should try to reach out to him."
    mc "Debería intentar comunicarme con el."

# game/endings.rpy:20
translate spanish ending_28ea0068:

    # "You find his contact."
    "Encuentras su contacto."

# game/endings.rpy:21
translate spanish ending_91f463ec:

    # mc "Yes! Let's give him a call!"
    mc "¡Cojonudo! ¡Vamos a hacerle una llamada!"

# game/endings.rpy:36
translate spanish ending_a584a973:

    # mf "I have reached enlightment...[cat]"
    mf "He alcanzado la iluminación...[cat]"

# game/endings.rpy:37
translate spanish ending_e0d13ad8:

    # mf "You turned me into the perfect being in every way.[cat]"
    mf "Me has convertido en el ser perfecto en todos los aspectos.[cat]"

# game/endings.rpy:38
translate spanish ending_1a16a375:

    # mf "I must thank you.[cat]"
    mf "Debo agradecertelo.[cat]"

# game/endings.rpy:39
translate spanish ending_e09a1716:

    # mf "You will reincarnate into a lotus flower in your next life.[cat]"
    mf "Te reencarnarás en una flor de loto en tu próxima vida.[cat]"

# game/endings.rpy:40
translate spanish ending_6040e426:

    # mf "Farewell...[cat]"
    mf "Hasta más ver...[cat]"

# game/endings.rpy:43
translate spanish ending_ab25040d:

    # centered "Ending: Enlightement"
    centered "Final: Iluminación"

# game/endings.rpy:52
translate spanish ending_8729fe5a:

    # mf "Hey, man. Thanks for this PUSH PUSH PUSH[cat]"
    mf "Hey, coleguita. Gracias por el QUE PIM QUE PAM.[cat]"

# game/endings.rpy:53
translate spanish ending_6ccdaa2a:

    # mf "I've learnt a lot about body building and also made a lot of friends at the gym.[cat]"
    mf "He aprendido mogollón sobre musculatura y también he hecho muchos amigos en el gym.[cat]"

# game/endings.rpy:54
translate spanish ending_63861b33:

    # mf "Thank you for this, it was worth every single penny, man.[cat]"
    mf "Gracias por todo, mereces cada centavo, colega.[cat]"

# game/endings.rpy:55
translate spanish ending_74caf356:

    # mf "I'll help other people become the better versions of themselves from now on just like you helped me.[cat]"
    mf "Voy a ayudar a otras personas a convertirse en versiones mejores de si mismos de ahora en adelante justo igual que tu me ayudaste.[cat]"

# game/endings.rpy:56
translate spanish ending_2b775482:

    # mf "I hope we can meet again soon, my friend.[cat]"
    mf "Espero que nos veamos pronto, colega.[cat]"

# game/endings.rpy:59
translate spanish ending_8a5b78e2:

    # centered "Ending: Gigachad"
    centered "Final: Gigachad"

# game/endings.rpy:70
translate spanish ending_19d84c39:

    # mf "hm, hm hm~...[cat]"
    mf "hm, hm hm~...[cat]"

# game/endings.rpy:71
translate spanish ending_aa95e088:

    # mf "Oh, haven't seen you there![cat]"
    mf "Oh, no te había visto![cat]"

# game/endings.rpy:72
translate spanish ending_fd83417d:

    # mf "Hold on, let me put this down so i can pay attention to you.[cat]"
    mf "Espera, deja que aparte esto para poder darte toda mi atención.[cat]"

# game/endings.rpy:76
translate spanish ending_ea99b767:

    # mf "Much better~.[cat]"
    mf "Mucho mejor~.[cat]"

# game/endings.rpy:77
translate spanish ending_15b9b9c3:

    # mf "Hey, baby. Wanna go for a drink with my 420 girlfriends?[cat]"
    mf "Hey, cielo. Quieres venir a tomar algo con mis 420 novias?[cat]"

# game/endings.rpy:78
translate spanish ending_23d1ecaf:

    # mf "Just kidding, kitten. I only have eyes for you, you know?[cat]"
    mf "Estoy de coña, gatito. Ya sabes que solo tengo ojos para ti.[cat]"

# game/endings.rpy:79
translate spanish ending_faec9d17:

    # mf "I just wanted to thank you properly for helping me out.[cat]"
    mf "Solo queria agradecertelo adecuadamente por echarme un cable.[cat]"

# game/endings.rpy:80
translate spanish ending_596a442f:

    # mf "How about we go to this nice new restaurant in town?[cat]"
    mf "¿Que te parece si vamos a ese nuevo restaurante en la ciudad?[cat]"

# game/endings.rpy:81
translate spanish ending_441f1d7e:

    # mf "My treat, of course. {p}I got hired as a model for a fashion magazine so don't worry about the money.[cat]"
    mf "Yo pago, por supuesto. {p}Me contrataron como modelo para una revista de moda asi que no te preocupes por el dinero.[cat]"

# game/endings.rpy:83
translate spanish ending_8474371d:

    # mf "See you soon, sweetheart.[cat]"
    mf "Nos vemos, cariño.[cat]"

# game/endings.rpy:86
translate spanish ending_72130219:

    # centered "Ending: Ikemen"
    centered "Ending: Ikemen"

# game/endings.rpy:95
translate spanish ending_4cec1040:

    # mf "Hello there![cat]"
    mf "Hola![cat]"

# game/endings.rpy:96
translate spanish ending_e8f9b2b2:

    # mf "Thanks to your help i've became the CEO of \"Pichula Logistics\"[cat]"
    mf "Gracias a tu ayuda me he convertido en el CEO de \"Pichula Logistics\"[cat]"

# game/endings.rpy:97
translate spanish ending_f7bbbcec:

    # mf "Everyone praises me and they always come to me when they need help.[cat]"
    mf "Todos me alaban y siempre acuden a mi cuando necesitan ayuda.[cat]"

# game/endings.rpy:98
translate spanish ending_9f6e6acb:

    # mf "I even have a girlfriend now. Her name is Y/N and she's so perfect in every aspect.[cat]"
    mf "Incluso tengo una novia ahora. Se llama T/N y es perfecta en todos los aspectos.[cat]"

# game/endings.rpy:99
translate spanish ending_1f6e5fda:

    # mf "DON'T TALK TO Y/N![cat]"
    mf "¡NO HABLES CON T/N![cat]"

# game/endings.rpy:100
translate spanish ending_dcaa3573:

    # mf "Bye.[cat]"
    mf "Chao.[cat]"

# game/endings.rpy:104
translate spanish ending_52a861aa:

    # centered "Ending: CEO"
    centered "Final: CEO"

# game/endings.rpy:112
translate spanish ending_9143dd51:

    # mf "What the FUCK do you want?[cat]"
    mf "¿Que COJONES quieres?[cat]"

# game/endings.rpy:113
translate spanish ending_ce35a1ef:

    # mf "Ive been busy keeping a rival gang at arm's length.[cat]"
    mf "He estado ocupado manteniendo a la banda rival a raya.[cat]"

# game/endings.rpy:114
translate spanish ending_aa51c863:

    # mf "Yesterday one of those fuckers got my fist for breakfast and his teeth for dinner.[cat]"
    mf "Ayer uno de esos cabrones se comió mi puño de desayuno y sus dientes de cena.[cat]"

# game/endings.rpy:115
translate spanish ending_1f765327:

    # mf "I mean it. {p}I gave him some salt, pepper and almost made him choke his fork too.[cat]"
    mf "Va en serio. {p}Hasta le pasé la sal, la pimienta y por poco le hago tragarse el tenedor y todo.[cat]"

# game/endings.rpy:117
translate spanish ending_fc5d42c3:

    # mf "Look, I'm thankful for what you did for me back when you were my coach but I'm a busy man now.[cat]"
    mf "Mira, estoy agradecido por lo que hicieste por mi en aquel entonces cuando eras mi coach pero soy un hombre ocupado ahora."

# game/endings.rpy:118
translate spanish ending_91d408f7:

    # mf "I would also hate for you to get hurt because of my new job. Can't be cautious enough these days...[cat]"
    mf "También seria un putadón que te hicieran daño por mi trabajo. No se puede ser lo suficientemente precavido en estos tiempos...[cat]"

# game/endings.rpy:119
translate spanish ending_ce02df5c:

    # mf "Take care, man... {p}And please don't contact me again unless you're into serious shit.[cat]"
    mf "Cuidate, tio... {p}Y por favor no contactes conmigo a no ser que estes metido en alguna mierda seria.[cat]"

# game/endings.rpy:123
translate spanish ending_d03470af:

    # centered "Ending: Bad boy"
    centered "Ending: Malote"

# game/endings.rpy:133
translate spanish ending_8645908e:

    # "There's no answer."
    "No hay respuesta."

# game/endings.rpy:134
translate spanish ending_0d37048b:

    # "You thought he might be busy at the moment."
    "Asumiste que estaría ocupado en ese momento."

# game/endings.rpy:135
translate spanish ending_cbd5dde9:

    # "Then you discovered what really happened to him."
    "Mas tarde descubriste que fue lo que le pasó en realidad."

# game/endings.rpy:136
translate spanish ending_195840d4:

    # "All of his hatred towards women and minorities led him to do a one man protest by himself."
    "Todo su odio hacia mujeres y minorias le llevó a organizar una protesta individual por si mismo."

# game/endings.rpy:137
translate spanish ending_17dd835b:

    # "He was on the road like the complete idiot he was... {p}Yes, I said \"was\""
    "Estaba en el medio de la carretera como el tremendo palurdo que era... {p}Si, dije \"era\"."

# game/endings.rpy:139
translate spanish ending_f96a2bad:

    # "Because while he was on that road... {p}He was ran over by a tanker truck."
    "Porque mientras estaba en la carretera... {p}Fue atropellado por un camión cisterna."

# game/endings.rpy:141
translate spanish ending_270c469a:

    # "And so he died."
    "Y así murió."

# game/endings.rpy:142
translate spanish ending_a482b714:

    # "And you realized that perhaps being a coach wasn't your thing after all..."
    "Y tú te diste cuenta de que tal vez ser un coach no es lo tuyo después de todo..."

# game/endings.rpy:145
translate spanish ending_fb048682:

    # centered "Ending: Hateful"
    centered "Final: Odio"

# game/endings.rpy:151
translate spanish ending_7d55f100:

    # mf "AAAAAAAAAAAAAAAAAAAAAAAHHHHHHHHHHHHHHHHHHHHHH[cat]"
    mf "AAAAAAAAAAAAAAAAAAAAAAAHHHHHHHHHHHHHHHHHHHHHH[cat]"

# game/endings.rpy:152
translate spanish ending_e1eca30d:

    # mf "I'M STILL THE SAME LOSER I WAS BEFORE THE COURSE BUT SOMEHOW EVEN MORE BROKE!![cat]"
    mf "¡¡SIGO SIENDO EL MISMO PANOLI QUE ERA ANTES DEL CURSO PERO AUN MAS POBRE QUE ANTES!![cat]"

# game/endings.rpy:154
translate spanish ending_60339690:

    # mf "Try to do it better next time, pretty please?[cat]"
    mf "¿Intenta hacerlo mejor la próxima, porfi plis?[cat]"

# game/endings.rpy:155
translate spanish ending_cf0eba09:

    # mf "Thanks for reaching out though![cat]"
    mf "¡Gracias por contactarme, por cierto![cat]"

# game/endings.rpy:156
translate spanish ending_dcaa3573_1:

    # mf "Bye.[cat]"
    mf "Chao.[cat]"

# game/endings.rpy:159
translate spanish ending_5631eb48:

    # centered "Ending: Loser"
    centered "Final: Perdedor"

# game/endings.rpy:169
translate spanish secret_endings_5902691b:

    # mc_nvl "I really like you too."
    mc_nvl "Me gustas mucho tu tambien."

# game/endings.rpy:170
translate spanish secret_endings_dd0afc94:

    # mf_nvl "Y-YOU DO????"
    mf_nvl "¿¿¿¿E-EN SERIO????"

# game/endings.rpy:171
translate spanish secret_endings_a4bb87c8:

    # mf_nvl "Omg"
    mf_nvl "Omg"

# game/endings.rpy:172
translate spanish secret_endings_32d6333b:

    # mf_nvl "I-I need a moment, please. I-I'll be back."
    mf_nvl "N-Necesito un momento, porfa. A-Ahora vuelvo."

# game/endings.rpy:174
translate spanish secret_endings_38291f57:

    # mc "Was I too forward with him?"
    mc "¿Fui demasiado directo con el?"

# game/endings.rpy:175
translate spanish secret_endings_f4b52495:

    # mc "Maybe this was too much..."
    mc "Tal vez fue demasiado..."

# game/endings.rpy:177
translate spanish secret_endings_81d372d6:

    # mc_nvl "Hey, are you okay?"
    mc_nvl "Hey, ¿Estás bien?"

# game/endings.rpy:179
translate spanish secret_endings_42225273:

    # mc_nvl "Honey?"
    mc_nvl "¿Cariño?"

# game/endings.rpy:181
translate spanish secret_endings_6fe04409:

    # mc_nvl "[mf_name]?"
    mc_nvl "¿[mf_name]?"

# game/endings.rpy:183
translate spanish secret_endings_ddee34f9:

    # mf_nvl "Y-yes, I'm fine![cat]"
    mf_nvl "S-Si, estoy bien![cat]"

# game/endings.rpy:184
translate spanish secret_endings_5503e2af:

    # mf_nvl "O-or at least I think so...[cat]"
    mf_nvl "O-O por lo menos eso creo...[cat]"

# game/endings.rpy:185
translate spanish secret_endings_6a6b27a5:

    # mf_nvl "My heart is beaing so fast...[cat]"
    mf_nvl "Siento que me va a explotar la patata...[cat]"

# game/endings.rpy:187
translate spanish secret_endings_20e110b2:

    # mf_nvl "D-Do you really mean it, though?...[cat]"
    mf_nvl "L-Lo dices en serio?...[cat]"

# game/endings.rpy:188
translate spanish secret_endings_c4a146f4:

    # mf_nvl "D-Do you like me?[cat]"
    mf_nvl "¿D-De verdad te gusto?[cat]"

# game/endings.rpy:190
translate spanish secret_endings_5213f66e:

    # mc "I was supposed to care only about the money but..."
    mc "Se suponia que solo me tenia que importar el dinero pero..."

# game/endings.rpy:191
translate spanish secret_endings_51b32b19:

    # mc "I really do, I really like him."
    mc "Lo cierto es que si, me gusta mucho."

# game/endings.rpy:192
translate spanish secret_endings_fc716191:

    # mc "He deserves to know."
    mc "Merece saberlo."

# game/endings.rpy:194
translate spanish secret_endings_5f3a64d4:

    # mc_nvl "Yes, I do."
    mc_nvl "Si, me gustas."

# game/endings.rpy:197
translate spanish secret_endings_2b499c80:

    # mc_nvl "I really like you, honey."
    mc_nvl "Me gustas muchísimo, cariño."

# game/endings.rpy:199
translate spanish secret_endings_3cdf2f59:

    # mc_nvl "I really like you, [mf_name]."
    mc_nvl "Me gustas muchísimo, [mf_name]."

# game/endings.rpy:200
translate spanish secret_endings_49712270:

    # mc_nvl "I like the way you smile when you achieve your goals."
    mc_nvl "Me gusta tu sonrisa cuando logras tus metas."

# game/endings.rpy:201
translate spanish secret_endings_04b6be67:

    # mc_nvl "I like the way you send me a message every morning."
    mc_nvl "Me gusta cuando me mandas mensajes cada mañana."

# game/endings.rpy:202
translate spanish secret_endings_9cdf7267:

    # mc_nvl "I like it when you tell me about your dreams."
    mc_nvl "Me gusta cuando me cuentas tus sueños."

# game/endings.rpy:203
translate spanish secret_endings_fbcfafc5:

    # mc_nvl "I like you."
    mc_nvl "Me gustas."

# game/endings.rpy:204
translate spanish secret_endings_86f31deb:

    # mc_nvl "And honestly I feel like I'm going crazy."
    mc_nvl "Y lo cierto es que siento que me estoy volviendo loco."

# game/endings.rpy:205
translate spanish secret_endings_ff0fd454:

    # mc_nvl "But I can't deny it, not anymore."
    mc_nvl "Pero no puedo negarlo, ya no."

# game/endings.rpy:206
translate spanish secret_endings_ee56b534:

    # mc_nvl "Can you turn on your cam for me?"
    mc_nvl "¿Podrías encender tu camara para mi?"

# game/endings.rpy:207
translate spanish secret_endings_905aa44c:

    # mc_nvl "I need to see you."
    mc_nvl "Necesito verte."

# game/endings.rpy:209
translate spanish secret_endings_a2d72e9e:

    # mf_nvl "O-okay...[cat]"
    mf_nvl "E-Esta bien...[cat]"

# game/endings.rpy:216
translate spanish secret_endings_d21862e5:

    # mf "W-Well, here I am...[cat]"
    mf "B-Bueno, pues aqui me tienes...[cat]"

# game/endings.rpy:217
translate spanish secret_endings_6cb865cb:

    # mf "I-I'm still struggling to process everything you said but...[cat]"
    mf "A-Aun me esta costando procesar todo lo que has dicho pero...[cat]"

# game/endings.rpy:219
translate spanish secret_endings_3621b223:

    # mf "It made me so happy.[cat]"
    mf "Me ha hecho muy feliz.[cat]"

# game/endings.rpy:220
translate spanish secret_endings_179d21db:

    # mf "I'm so glad our feelings are mutual, [mc_name].[cat]"
    mf "Me alegra que nuestros sentimientos sean mutuos, [mc_name].[cat]"

# game/endings.rpy:221
translate spanish secret_endings_e61829a6:

    # mf "I like you so much, I truly do.[cat]"
    mf "Me gustas mucho, de verdad.[cat]"

# game/endings.rpy:223
translate spanish secret_endings_0390aabb:

    # mf "Will this interfere with the course, though?[cat]"
    mf "Aunque... ¿Esto interferirá con el curso?[cat]"

# game/endings.rpy:224
translate spanish secret_endings_d031dc1d:

    # mc "Don't worry about the course."
    mc "No te preocupes por el curso."

# game/endings.rpy:225
translate spanish secret_endings_cb3272bb:

    # mc "I need to be honest with you."
    mc "Necesito ser honesto contigo."

# game/endings.rpy:226
translate spanish secret_endings_5f05724b:

    # mc "When I posted this course online I only cared about the money..."
    mc "Cuando subí este curso online solo me importaba el dinero..."

# game/endings.rpy:227
translate spanish secret_endings_6345dd03:

    # mc "I owe a lot of money to a loan shark... {p}Money that I then lost on horse racing bets."
    mc "Debo mucho dinero a un prestamista... {p}Dinero que mas tarde perdí en apuestas de caballos."

# game/endings.rpy:229
translate spanish secret_endings_d66dfbd0:

    # mc "When we met for the first time I saw you as an ATM machine and I'm deeply embarrased of myself for that."
    mc "Cuando te conocí por primera vez te vi como un cajero automático y estoy muy avergonzado por eso."

# game/endings.rpy:230
translate spanish secret_endings_2ec2c66b:

    # mc "Because as I got to know you more I realized that money wasn't the most important thing after all."
    mc "Porque cuando empecé a conocerte más me di cuenta de que el dinero no es lo mas importante después de todo."

# game/endings.rpy:232
translate spanish secret_endings_d0326be2:

    # mf "A-A loan shark?[cat]"
    mf "¿U-Un prestamista?[cat]"

# game/endings.rpy:233
translate spanish secret_endings_62a7616a:

    # mf "Is there anything I can do to help?[cat]"
    mf "¿Hay algo que pueda hacer para ayudar?[cat]"

# game/endings.rpy:234
translate spanish secret_endings_c987398b:

    # mf "I don't want them to hurt you![cat]"
    mf "¡No quiero que te hagan daño![cat]"

# game/endings.rpy:237
translate spanish secret_endings_ea02a444:

    # mc "Don't worry about me, honey."
    mc "No te preocupes por mi, cariño."

# game/endings.rpy:239
translate spanish secret_endings_0cf787d9:

    # mc "Don't worry about me, [mf_name]."
    mc "No te preocupes por mi, [mf_name]."

# game/endings.rpy:241
translate spanish secret_endings_f61e4089:

    # mc "I'll find other ways to pay back."
    mc "Encontraré otras formas de pagar mi deuda."

# game/endings.rpy:242
translate spanish secret_endings_942a3104:

    # mc "Honest ways."
    mc "Formas honestas."

# game/endings.rpy:244
translate spanish secret_endings_e0615824:

    # mf "B-But...[cat]"
    mf "P-Pero...[cat]"

# game/endings.rpy:246
translate spanish secret_endings_79cd4499:

    # mc "Hey, now that I think about it perhaps there is a way for you to help me."
    mc "Oye, ahora que lo pienso tal vez si que hay algo que puedes hacer para ayudarme."

# game/endings.rpy:248
translate spanish secret_endings_7d1f2d68:

    # mf "Really? Please tell me![cat]"
    mf "¿De verdad? ¡Por favor, dimelo![cat]"

# game/endings.rpy:249
translate spanish secret_endings_e84a3c64:

    # mc "Just stay by my side, please?"
    mc "¿Quedate a mi lado, por favor?"

# game/endings.rpy:251
translate spanish secret_endings_15245d6d:

    # mf "I will.[cat]"
    mf "Lo haré.[cat]"

# game/endings.rpy:252
translate spanish secret_endings_9ab57689:

    # mf "I promise.[cat]"
    mf "Lo prometo.[cat]"

# game/endings.rpy:257
translate spanish secret_endings_14e7a760:

    # "And so [mf_name] and you lived happily ever after."
    "Y así [mf_name] y tu vivisteis felices para siempre."

# game/endings.rpy:258
translate spanish secret_endings_0c4d6cd7:

    # "[mf_name] took you in as his roommate so you wouldn't have to pay rent anymore."
    "[mf_name] te acogió en su habitación para que no tengas que pagar mas el alquiler."

# game/endings.rpy:259
translate spanish secret_endings_3ae2a8bb:

    # "He also helped you get a job at the same place he works, and eventually, you paid off your debts."
    "También te ayudó a conseguir un puesto en el mismo sitio que el trabaja, y eventualmente, pagaste tu deuda."

# game/endings.rpy:260
translate spanish secret_endings_9b2a8d3f:

    # "Now, the two of you live peacefully together, always there to support one another."
    "Ahora los dos vivís juntos pacíficamente, apoyandoos mutuamente siempre."

# game/endings.rpy:264
translate spanish secret_endings_5d13dcb4:

    # centered "Ending: He fixed you."
    centered "Final: Él te arregló."

