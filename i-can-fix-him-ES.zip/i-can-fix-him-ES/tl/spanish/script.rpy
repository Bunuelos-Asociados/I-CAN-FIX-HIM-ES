﻿
# game/script.rpy:15
translate spanish select_mc_hobby_dacc999f:

    # "You can't leave this blank."
    "No puedes dejar esto en blanco."

# game/script.rpy:33
translate spanish select_mc_name_dacc999f:

    # "You can't leave this blank."
    "No puedes dejar esto en blanco."

# game/script.rpy:50
translate spanish select_mf_name_6aca333f:

    # "He can't have the same name as you."
    "No puede tener el mismo nombre que tu."

# game/script.rpy:53
translate spanish select_mf_name_dacc999f:

    # "You can't leave this blank."
    "No puedes dejar esto en blanco."

# game/script.rpy:86
translate spanish start_9f6ff0ad:

    # "Ever since I was a child I had one wish... {p}To become FILTHY FUCKING RICH."
    "Desde que era un mocoso solo he tenido un sueño... {p}convertirme en un JODIDO MILLONARIO."

# game/script.rpy:88
translate spanish start_4b36e1dc:

    # "I've tried many ways to achieve my lifelong dream but none of them worked."
    "Lo he intentado de muchas maneras pero ninguna me ha funcionado."

# game/script.rpy:89
translate spanish start_176c5938:

    # "I even owe a lot of money to a loan shark at the moment and I need to pay back if I don't want my ass drowning in the ocean."
    "Incluso le debo un pastizal a un prestamista y necesito pagarle cuanto antes si no quiero acabar siendo comida para los peces."

# game/script.rpy:90
translate spanish start_dab83ccc:

    # "Luckily for me I think I found the way to achieve my goal."
    "Afortunadamente para mi creo que he encontrado mi forma de conseguir mi objetivo."

# game/script.rpy:94
translate spanish start_3783755e:

    # "It's been a week since I've graduated from a cheap coaching course online."
    "Ha pasado una semana desde que me gradué de un cursillo de coaching online mierdoso."

# game/script.rpy:95
translate spanish start_f00137c6:

    # "Now it's time for me to shine in the coaching field by helping another young men find their place in the world... {p}And for their money to find its place in my bank account."
    "Ahora es mi turno de brillar en el mundo del coaching ayudando a otros jovenes a encontrar su lugar en este mundo... {p}Y para que su dinero encuentre su lugar en mi cuenta bancaria."

# game/script.rpy:101
translate spanish start_45cfb9f5:

    # "First I need to register in the CoachHub"
    "Primero necesito registrarme en el CoachHub"

# game/script.rpy:104
translate spanish start_afbab465:

    # mc "I'm ready to post my course online now."
    mc "Ya estoy listo para subir mi curso online."

# game/script.rpy:105
translate spanish start_c1447d5c:

    # mc "I'm about to become rich in no time!"
    mc "¡Estoy a un paso de hacerme rico!"

# game/script.rpy:109
translate spanish start_7d8afbe4:

    # "You received a notification."
    "Has recibido una notificación."

# game/script.rpy:111
translate spanish start_6057ddcc:

    # mc "Well, that was fast..."
    mc "Vaya, que rapido..."

# game/script.rpy:115
translate spanish start_7ab595c1:

    # mc "Oh, someone already signed in??"
    mc "Oh, ¿¿Alguien se ha apuntado ya??"

# game/script.rpy:116
translate spanish start_c31a211d:

    # mc "Is he dumb-? I-I mean... Is he rich and bored?"
    mc "¿Es imbecil? Q-Quiero decir... ¿Es rico y esta aburrido como una ostra?"

# game/script.rpy:117
translate spanish start_f3020465:

    # mc "Let's see... {p}His name is..."
    mc "Veamos... {p}Su nombre es..."

# game/script.rpy:122
translate spanish start_0432d1cc:

    # mc "Alright... Let's see [mf_name]'s message..."
    mc "Muy bien... Veamos el mensaje de [mf_name]..."

# game/script.rpy:126
translate spanish start_d41d8cd9:

    # nvl clear
    nvl clear

# game/script.rpy:129
translate spanish start_5f83136f:

    # mf_nvl "H-hello is this [mc_name]? I-I'm interested in the coaching service...[cat]"
    mf_nvl "H-Hola, hablo con [mc_name]? E-Estoy interesado en el servicio de coaching...[cat]"

# game/script.rpy:130
translate spanish start_fda71b71:

    # mf_nvl "If it isn't available I understand! I don't want to be a bother tbh.[cat]"
    mf_nvl "¡Si no está disponible lo entiendo! No quiero ser una molestia, la verdad.[cat]"

# game/script.rpy:131
translate spanish start_00066198:

    # mf_nvl "P-please respond?[cat]"
    mf_nvl "P-Porfa responda.[cat]"

# game/script.rpy:132
translate spanish start_281ee7d6:

    # mf_nvl "Or not... I'm insignificant hehe...[cat]"
    mf_nvl "O no... Soy insignificante jeje...[cat]"

# game/script.rpy:134
translate spanish start_7017e02c:

    # mc "Damn, this guy got issues..."
    mc "Hostias, este tio tiene problemas..."

# game/script.rpy:135
translate spanish start_d8f5527d:

    # mc "Money, here we come!!"
    mc "¡¡Dinerito, allá voy!!"

# game/script.rpy:137
translate spanish start_bb87ca17:

    # mf_nvl "Hello?...[cat]"
    mf_nvl "¿Hola?...[cat]"

# game/script.rpy:141
translate spanish start_1c8d8841:

    # mc_nvl "Hello, my good man! Welcome to the course."
    mc_nvl "¡Buenas, buen hombre! Bienvenido al curso."

# game/script.rpy:142
translate spanish start_68aa0f5c:

    # mf_nvl "Oh my god, you actually responded[cat]"
    mf_nvl "Ay, dios mio. Al final has respondido.[cat]"

# game/script.rpy:143
translate spanish start_df4eeba8:

    # mf_nvl "W-what should I do?[cat]"
    mf_nvl "¿Q-Que debería hacer?[cat]"

# game/script.rpy:144
translate spanish start_24f6ca56:

    # mf_nvl "This is the first time someone responds to me...[cat]"
    mf_nvl "Es la primera vez que alguien me responde...[cat]"

# game/script.rpy:145
translate spanish start_d1039a0c:

    # mc_nvl "First of all"
    mc_nvl "Antes que nada."

# game/script.rpy:148
translate spanish start_93873fa9:

    # mc_nvl "Have you paid yet?"
    mc_nvl "¿Has pagado ya?"

# game/script.rpy:149
translate spanish start_65e8af83:

    # mf_nvl "O-oh! right!![cat]"
    mf_nvl "¡¡A-Ah, si!![cat]"

# game/script.rpy:150
translate spanish start_137ec657:

    # mf_nvl "Just give me a sec[cat]"
    mf_nvl "Solo dame un segundo[cat]"

# game/script.rpy:154
translate spanish start_f220d76d:

    # mf_nvl "I-Is this enough?[cat]"
    mf_nvl "A-Así es suficiente?[cat]"

# game/script.rpy:155
translate spanish start_fcf3d47b:

    # mf_nvl "I hope it's enough...[cat]"
    mf_nvl "Espero que sea suficiente...[cat]"

# game/script.rpy:157
translate spanish start_7478f3e2:

    # mc "Oh my god he actually paid."
    mc "Ay dios, pues si que ha pagado."

# game/script.rpy:158
translate spanish start_0bbdafd8:

    # mc_nvl "Yes, that will work for the introductions."
    mc_nvl "Si, eso sería suficiente para la entrada."

# game/script.rpy:159
translate spanish start_079aee7d:

    # mc_nvl "I'm gonna need you to pay at the end of every session from now on."
    mc_nvl "Necesitare que pagues al final de cada sesión a partir de ahora."

# game/script.rpy:160
translate spanish start_a033800a:

    # mf_nvl "I-If it's not too rude to ask...[cat]"
    mf_nvl "S-Si no es de mala educación preguntar...[cat]"

# game/script.rpy:161
translate spanish start_2f580038:

    # mf_nvl "How long is this program gonna be? I have a budget of 700$, well, now it's 600$.[cat]"
    mf_nvl "Cuánto tiempo durará este programa? Tengo un presupuesto de 700$, bueno, ahora son 600$.[cat]"

# game/script.rpy:162
translate spanish start_f934b648:

    # mf_nvl "Basically all my monthly income.[cat]"
    mf_nvl "Básicamente todo mi salario mensual.[cat]"

# game/script.rpy:163
translate spanish start_26f84704:

    # mf_nvl "I worked in retail last month[cat]"
    mf_nvl "Trabajé en una tienda el mes pasado.[cat]"

# game/script.rpy:164
translate spanish start_34199e18:

    # mc_nvl "Let's see..."
    mc_nvl "Veamos..."

# game/script.rpy:165
translate spanish start_3357fb32:

    # mc_nvl "That'll cover for 7 days"
    mc_nvl "Eso cubrirá unos 7 días."

# game/script.rpy:166
translate spanish start_aacf600d:

    # mf_nvl "Oh...[cat]"
    mf_nvl "Oh...[cat]"

# game/script.rpy:167
translate spanish start_1378c3e0:

    # mf_nvl "I-if it isn't enough for the full course I can look somewhere else.[cat]"
    mf_nvl "S-Si no es suficiente para el curso completo puedo buscar en otro sitio.[cat]"

# game/script.rpy:169
translate spanish start_6a8d711c:

    # mc "Look somewhere else??? Who does he think he is???"
    mc "¿¿Buscar en otro sitio?? ¿¿¿Quién se cree que es???"

# game/script.rpy:170
translate spanish start_b2f82cac:

    # mc "I NEED to make him stay to get those lasting 600$!!"
    mc "¡¡NECESITO hacer que se quede para conseguir esos 600$ restantes!!"

# game/script.rpy:174
translate spanish start_f7a79d72:

    # mc_nvl "It's enough"
    mc_nvl "Es suficiente."

# game/script.rpy:175
translate spanish start_605f6486:

    # mc_nvl "Usually I'd charge more but you seem so desperate..."
    mc_nvl "Normalmente cobraría mas pero pareces tan desesperado..."

# game/script.rpy:176
translate spanish start_231dc760:

    # mf_nvl "W-well...[cat]"
    mf_nvl "B-Bueno...[cat]"

# game/script.rpy:177
translate spanish start_74a58315:

    # mf_nvl "I kinda am, ngl...[cat]"
    mf_nvl "Si que lo estoy, la verdad...[cat]"

# game/script.rpy:178
translate spanish start_42df7ace:

    # mf_nvl "I got fired recently because I was too scared to talk to customers.[cat]"
    mf_nvl "Me despidieron recientemente porque me daba miedo hablar con los clientes.[cat]"

# game/script.rpy:179
translate spanish start_3539c752:

    # mf_nvl "Mainly GIRL customers...[cat]"
    mf_nvl "En especial con las clientas MUJERES...[cat]"

# game/script.rpy:181
translate spanish start_a57cfad2:

    # mc "Hmm... So he's scared of women it seems."
    mc "Hmm... Así que le acojonan las pibitas al parecer."

# game/script.rpy:182
translate spanish start_3e73d8ce:

    # mc "I guess I can work with that."
    mc "Supongo que podemos trabajar en ello."

# game/script.rpy:184
translate spanish start_c5384490:

    # mf_nvl "And MEN customers too!![cat]"
    mf_nvl "¡¡Y con los clientes HOMBRES tambien!![cat]"

# game/script.rpy:187
translate spanish start_bf14c759:

    # mc_nvl "What about non binary customers?"
    mc_nvl "¿Y que hay de clientes no binarios?"

# game/script.rpy:188
translate spanish start_22c67493:

    # mf_nvl "They scare the shit out of me too.[cat]"
    mf_nvl "Me acojonan que no veas tambien.[cat]"

# game/script.rpy:190
translate spanish start_0b5c191b:

    # mc_nvl "Is there a reason why?"
    mc_nvl "¿Hay algún motivo en concreto?"

# game/script.rpy:191
translate spanish start_221012bb:

    # mf_nvl "Idk maybe I'm built different.[cat]"
    mf_nvl "No lo se, tal vez estoy hecho de otra pasta.[cat]"

# game/script.rpy:192
translate spanish start_b359af01:

    # mf_nvl "Badly.[cat]"
    mf_nvl "Pasta mala que te cagas.[cat]"

# game/script.rpy:193
translate spanish start_45a10899:

    # mf_nvl "But different nonetheless.[cat]"
    mf_nvl "Pero distinta, al fin y al cabo.[cat]"

# game/script.rpy:195
translate spanish start_8e642e5b:

    # mf_nvl "And that's not my only issue...[cat]"
    mf_nvl "Y ese no es mi unico problemilla...[cat]"

# game/script.rpy:196
translate spanish start_180b37b7:

    # mc_nvl "Alright, spit it out."
    mc_nvl "Muy bien, cuéntame."

# game/script.rpy:197
translate spanish start_82153dd9:

    # mf_nvl "I-It's kind of embarrasing but...[cat]"
    mf_nvl "M-Me da un poco de verguenza pero...[cat]"

# game/script.rpy:198
translate spanish start_01bf928c:

    # mf_nvl "I've never had a girlfriend before and everyone in college used to pick on me for being a virgin.[cat]"
    mf_nvl "Nunca he tenido novia y todos en la uni se burlaban de mi por ser un virgen.[cat]"

# game/script.rpy:199
translate spanish start_0aacc6b6:

    # mc_nvl "Man, that's rough."
    mc_nvl "Colega, que jodido."

# game/script.rpy:200
translate spanish start_99f77900:

    # mf_nvl "Ikr??[cat]"
    mf_nvl "¿¿Verdad??[cat]"

# game/script.rpy:201
translate spanish start_25acadf0:

    # mf_nvl "So...[cat]"
    mf_nvl "Así que...[cat]"

# game/script.rpy:202
translate spanish start_b4d64144:

    # mf_nvl "Please help me become less of a loser?[cat]"
    mf_nvl "¿Me ayudaras a ser un poquitín menos pringado, porfi?[cat]"

# game/script.rpy:203
translate spanish start_2865fd4f:

    # mc_nvl "Idk man... I can only help you so much but I can't actually do miracles."
    mc_nvl "No lo sé, tio... Puedo ayudar un poco pero no puedo hacer milagros."

# game/script.rpy:204
translate spanish start_b8ba472f:

    # mf_nvl "Please, please, please, please, please, please, please, please, please, please??????[cat]"
    mf_nvl "¿¿¿¿¿¿Porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi??????[cat]"

# game/script.rpy:205
translate spanish start_0ea6066b:

    # mf_nvl "Please with a cherry on top???????[cat]"
    mf_nvl "¿¿¿¿¿¿¿Porfi plis mil trillones de veces???????[cat]"

# game/script.rpy:206
translate spanish start_1f8fa0ea:

    # mf_nvl "I-I mean, I already PAID you for this chatting session...[cat]"
    mf_nvl "E-Es decir, yo ya te he PAGADO por esta sesion de chat...[cat]"

# game/script.rpy:208
translate spanish start_2baaf1ca:

    # mc "MAN THIS GUY'S ANNOYING!!"
    mc "¡¡ESTE TIPEJO ES UN PLASTA DE LA HOSTIA!!"

# game/script.rpy:212
translate spanish start_4f5c1125:

    # mc_nvl "Beg more."
    mc_nvl "Suplica más."

# game/script.rpy:213
translate spanish start_9df8419c:

    # mf_nvl "Even MORE??[cat]"
    mf_nvl "¿¿Aún MÁS??[cat]"

# game/script.rpy:214
translate spanish start_2ec0cbc9:

    # mf_nvl "O-okay, here goes nothing...[cat]"
    mf_nvl "V-Venga, va...[cat]"

# game/script.rpy:215
translate spanish start_25abfffc:

    # mf_nvl "Please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please, please??????[cat]"
    mf_nvl "¿¿¿¿¿¿Porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi, porfi??????[cat]"

# game/script.rpy:218
translate spanish start_f85f68d2:

    # mc_nvl "Enough."
    mc_nvl "Suficiente."

# game/script.rpy:220
translate spanish start_3d6dac66:

    # mc_nvl "Okay, okay..."
    mc_nvl "Vale, está bien..."

# game/script.rpy:221
translate spanish start_8cfd3d24:

    # mc_nvl "Let's see what I can do."
    mc_nvl "Veamos qué puedo hacer."

# game/script.rpy:222
translate spanish start_0afd09fd:

    # mc_nvl "No refunds, tho"
    mc_nvl "Nada de reembolsos, claro."

# game/script.rpy:223
translate spanish start_b47f354e:

    # mf_nvl "Really??? Begging actually WORKED for once???[cat]"
    mf_nvl "¿¿¿En serio??? ¿¿¿Suplicar ha FUNCIONADO por una vez en la vida???[cat]"

# game/script.rpy:224
translate spanish start_6efb9f14:

    # mf_nvl "YIPPEE!![cat]"
    mf_nvl "¡¡YIPPEE!![cat]"

# game/script.rpy:225
translate spanish start_a3d4fa1a:

    # mf_nvl "I CAN ALREADY SEE HOW THIS IS WORKING![cat]"
    mf_nvl "¡YA PUEDO VER COMO EL CURSO ESTÁ FUNCIONANDO![cat]"

# game/script.rpy:226
translate spanish start_bf683a40:

    # mc_nvl "First of all."
    mc_nvl "Primero que todo."

# game/script.rpy:227
translate spanish start_41bb7d3e:

    # mc_nvl "Stop saying \"YIPPEE\""
    mc_nvl "Deja de decir \"YIPPEE\"."

# game/script.rpy:228
translate spanish start_edcd5862:

    # mc_nvl "It's ridiculous."
    mc_nvl "Es ridículo de cojones."

# game/script.rpy:229
translate spanish start_3fa6e7a3:

    # mf_nvl "Y-Yes, master!![cat]"
    mf_nvl "¡¡S-Si, maestro!![cat]"

# game/script.rpy:230
translate spanish start_0344f0cf:

    # mc_nvl "WTF???"
    mc_nvl "¿¿¿PERO QUE COJONES???"

# game/script.rpy:231
translate spanish start_5c9728c6:

    # mc_nvl "IS THIS SOME KIND OF FUCKED UP KINK??"
    mc_nvl "¿¿ES ESTO ALGUN FETICHE RARO DE ESOS??"

# game/script.rpy:232
translate spanish start_ac3014e5:

    # mc_nvl "BECAUSE I DON'T FW THAT"
    mc_nvl "PORQUE NO ME MOLA NI UN PELO"

# game/script.rpy:233
translate spanish start_e06f8a7e:

    # mf_nvl "W-What??[cat]"
    mf_nvl "¿¿Q-Que??[cat]"

# game/script.rpy:234
translate spanish start_1af6c29c:

    # mf_nvl "Not at all!!![cat]"
    mf_nvl "¡¡¡Para nada!!![cat]"

# game/script.rpy:235
translate spanish start_5cbe13f1:

    # mf_nvl "It's like a master-disciple thing![cat]"
    mf_nvl "¡Es algo asi como una movida de maestro y discipulo![cat]"

# game/script.rpy:236
translate spanish start_c34e67b6:

    # mf_nvl "You know, like in ancient China?[cat]"
    mf_nvl "Ya sabes, como en la antigua China.[cat]"

# game/script.rpy:238
translate spanish start_e1f55348:

    # mc "\"Ancient China\" he says... {p}Lord help me."
    mc "\"Antigua China\" dice... {p}Señor dame paciencia."

# game/script.rpy:241
translate spanish start_9bc79baf:

    # mc_nvl "Alright, enough of that"
    mc_nvl "Bueno, sucidiente de esto."

# game/script.rpy:242
translate spanish start_81b904d3:

    # mc_nvl "Let's start with the first session."
    mc_nvl "Empecemos con la primera sesión."

# game/script.rpy:243
translate spanish start_e2e6e96f:

    # mc_nvl "I'm gonna need you to turn on your cam."
    mc_nvl "Voy a necesitar que vayas encendiendo la camara."

# game/script.rpy:244
translate spanish start_3cd6ea18:

    # mf_nvl "W-wha-??[cat]"
    mf_nvl "¿¿Q-Que??[cat]"

# game/script.rpy:245
translate spanish start_0b1786ee:

    # mf_nvl "H-Hold on, let me tidy up a bit first!![cat]"
    mf_nvl "¡¡E-Espera, deja que ordene un poco antes!![cat]"

# game/script.rpy:246
translate spanish start_a1c1d6cb:

    # mc_nvl "Turn on the cam. Now."
    mc_nvl "Enciende la camara. Ahora."

# game/script.rpy:247
translate spanish start_9827811d:

    # mf_nvl "O-Okay, master...[cat]"
    mf_nvl "S-Si, maestro...[cat]"

# game/script.rpy:249
translate spanish start_d41d8cd9_1:

    # nvl clear
    nvl clear

# game/script.rpy:256
translate spanish start_545950be:

    # "So this is the guy... {p}Looks lame af."
    "Así que este es el fulano... {p}Menudas pintas me trae."

# game/script.rpy:259
translate spanish start_104d57c4:

    # mf "H-hello...[cat]"
    mf "H-Hola...[cat]"

# game/script.rpy:262
translate spanish start_c48c1da1:

    # mf "AAAAAAh I LOOK AWFUL!!![cat]"
    mf "¡¡¡AAAAAAh SALGO HORRIBLE!!![cat]"

# game/script.rpy:263
translate spanish start_d649d7db:

    # mf "THIS IS WHY GIRLS DON'T WANT ME.[cat]"
    mf "POR ESO LAS CHICAS NO ME QUIEREN NI REGALADO.[cat]"

# game/script.rpy:264
translate spanish start_0b326486:

    # mf "It SUCKS to live in a world where nice guys finish last![cat]"
    mf "¡Como JODE vivir en un mundo donde los tipos buenos acaban siendo el último mono![cat]"

# game/script.rpy:266
translate spanish start_333db692:

    # mc "[mf_name], lock the fuck in."
    mc "[mf_name], céntrate."

# game/script.rpy:269
translate spanish start_7409fea8:

    # mf "Y-Yes, master.[cat]"
    mf "S-Si, maestro.[cat]"

# game/script.rpy:271
translate spanish start_5c6ab99d:

    # mf "I'm ready to start![cat]"
    mf "¡Estoy listo para empezar![cat]"

# game/script.rpy:273
translate spanish start_bd582f44:

    # mc "Okay let's do this"
    mc "Vale, vamos a ello."

# game/script.rpy:277
translate spanish start_a622a4c0:

    # "{color=#00ff00}TUTORIAL: You have to manage [mf_name] stats to help him become a better man by the end of the 7 days.{/color}"
    "{color=#00ff00}TUTORIAL: Debes administrar las estadísticas de [mf_name] para ayudarle a convertirse en un mejor hombre al final de los 7 días.{/color}"

# game/script.rpy:278
translate spanish start_30c3cac9:

    # "{color=#00ff00}Actions like going to work or to the gym costs stamina and hours. You can buy items to increase his stats and recharge his stamina.{/color}"
    "{color=#00ff00}Acciones como ir al trabajo o al gimnasio consumen estamina y horas. Puedes comprar objetos para aumentar sus estadísticas y recargar su estamina.{/color}"

# game/script.rpy:279
translate spanish start_c0274439:

    # "{color=#00ff00}Actions like going to the gym, the salon or the club costs money too.{/color}"
    "{color=#00ff00}Acciones como ir al gimnasio, a la peluquería o al club también cuestan dinero.{/color}"

# game/script.rpy:301
translate spanish main_state_e6392bf8:

    # mf "It's too late now... The day already ended.[cat]"
    mf "Ya es muy tarde... El día ya se ha terminado.[cat]"

# game/script.rpy:333
translate spanish new_day_bd177019:

    # mf "Let me pay you real quick.[cat]"
    mf "Deja que te pague rapidito.[cat]"

# game/script.rpy:335
translate spanish new_day_29ec1ba2:

    # mf "See you tomorrow![cat]"
    mf "¡No vemos mañana![cat]"

# game/script.rpy:353
translate spanish new_day_5b3d73d6:

    # mf "A-Actually, wait...[cat]"
    mf "E-En realidad, espera...[cat]"

# game/script.rpy:355
translate spanish new_day_c32a70b6:

    # mf "I-I need to tell you something before you go if that's okay...[cat]"
    mf "N-Necesito decirte algo antes de que te vayas, si te parece bien...[cat]"

# game/script.rpy:358
translate spanish new_day_06cf174d:

    # mf "Really? W-well then, here goes nothing.[cat]"
    mf "¿En serio? Bueno, pues ahí va.[cat]"

# game/script.rpy:359
translate spanish new_day_700f72f6:

    # mf "I'm so glad I signed up for this course. Meeting you was one of the highlights of my life...[cat]"
    mf "Me alegro mucho de haberme inscrito en este curso. Conocerte fue uno de los mejores momentos de mi vida...[cat]"

# game/script.rpy:360
translate spanish new_day_000d2e65:

    # mf "It's not an exaggeration. You're so nice and patient with me and sometimes you don't think I'm a total loser.[cat]"
    mf "No exagero. Eres muy bueno y paciente conmigo, y a veces no opinas que sea un completo panoli.[cat]."


# game/script.rpy:361
translate spanish new_day_cc9dc1bb:

    # mf "I'm so glad I met you. {p}Thank you for not giving up on me. Thank you for everything.[cat]"
    mf "Me alegro mucho de haberte conocido. {p}Gracias por no rendirte conmigo. Gracias por todo.[cat]"

# game/script.rpy:364
translate spanish new_day_b701e28d:

    # mf "W-Well, that's all! Thank you for listening to what I had to say[cat]"
    mf "¡B-Bueno, pues eso era todo! Gracias por escuchar lo que tenía que decir.[cat]"

# game/script.rpy:366
translate spanish new_day_6b9e6e6d:

    # mf "Sleep well, [mc_name].[cat]"
    mf "Duerme bien, [mc_name].[cat]"

# game/script.rpy:370
translate spanish new_day_480e5fce:

    # mf "O-oh I understand...[cat]"
    mf "O-Oh, entiendo...[cat]"

# game/script.rpy:372
translate spanish new_day_247577b9:

    # mf "You must be so tired now.[cat]"
    mf "Debes estar muy cansado.[cat]"

# game/script.rpy:374
translate spanish new_day_4cb4e598:

    # mf "Sleep well![cat]"
    mf "¡Duerme bien![cat]"

translate spanish strings:

    # game/script.rpy:11
    old "What's your hobby?"
    new "¿Cual es tu hobby?"

    # game/script.rpy:28
    old "Introduce your user name"
    new "Introduce tu nombre de usuario."

    # game/script.rpy:44
    old "What is your client's name?"
    new "¿Cual es el nombre de tu cliente?"

    # game/script.rpy:69
    old "This game was made for satirical purposes and should not be taken seriously. Any similarities with real events are pure coincidence."
    new "Este juego fue creado con fines satíricos y no debe tomarse en serio. Cualquier similitud con hechos reales es pura coincidencia."

    # game/script.rpy:72
    old "A MEOWDY NIO GAME"
    new "UN JUEGO DE MEOWDY NIO"

    # game/script.rpy:140
    old "Hello, my good man! Welcome to the course."
    new "¡Buenas, buen hombre! Bienvenido al curso."

    # game/script.rpy:147
    old "Have you paid yet?"
    new "¿Has pagado ya?"

    # game/script.rpy:173
    old "It's enough"
    new "Es suficiente."

    # game/script.rpy:186
    old "What about non binary customers?"
    new "¿Y que hay de clientes no binarios?"

    # game/script.rpy:189
    old "Is there a reason why?"
    new "¿Hay algún motivo en concreto?"

    # game/script.rpy:211
    old "Beg more."
    new "Suplica más."

    # game/script.rpy:217
    old "Enough."
    new "Suficiente."

    # game/script.rpy:357
    old "Sure."
    new "Claro."

    # game/script.rpy:369
    old "Maybe another time."
    new "Tal vez en otro momento."

    old "Ending: Enlightement"
    new "Final: Iluminación"

    old "Ending: Gigachad"
    new "Final: Gigachad"

    old "Ending: Ikemen"
    new "Final: chico guapo"

    old "Ending: Bad boy"
    new "Final: chico malo"

    old "Ending: Hateful"
    new "Final: Odioso"

    old "Ending: Loser"
    new "Final: Perdedor"

    old "Ending: He fixed you."
    new "Final: Te ha arreglado."
