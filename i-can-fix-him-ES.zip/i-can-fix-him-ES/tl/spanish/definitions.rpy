﻿
translate spanish strings:

    # game/definitions.rpy:146
    old " increased by "
    new " Incrementado por "

    # game/definitions.rpy:191
    old "You received "
    new "Recibiste "

    # game/definitions.rpy:246
    old "You lost "
    new "Has perdido "

    # game/definitions.rpy:253
    old "$"
    new "$"

    # game/definitions.rpy:280
    old "You bought "
    new "Has comprado "

    # game/definitions.rpy:289
    old "You don't have enough money"
    new "No tienes suficiente dinero"

    # game/definitions.rpy:334
    old "Glasses"
    new "Gafas"

    # game/definitions.rpy:334
    old "Use them to put on his glasses."
    new "Usalas para ponerle sus gafas."

    # game/definitions.rpy:349
    old "Protein Bar"
    new "Barrita de proteínas."

    # game/definitions.rpy:349
    old "What is this made of? Who knows..."
    new "¿Que qué lleva? Quien sabe..."

    # game/definitions.rpy:362
    old "Energy drink + coffee"
    new "Bebida energética + café"

    # game/definitions.rpy:362
    old "Gives you one extra hour for the current day. How? Don't ask me, I don't understand it either."
    new "Te condece una hora mas para el dia actual. Como? Ni zorra, yo tampoco lo entiendo."

    # game/definitions.rpy:377
    old "Self Help Book"
    new "Libro de auto ayuda"

    # game/definitions.rpy:377
    old "Book written by a multi millionaire CEO about how to put your life together (According to him)."
    new "Libro escrito por un CEO multimillonetis sobre como tomar las riendas de tu vida y hacerse a uno mismo (Según el)."

    # game/definitions.rpy:391
    old "Self Help Book Vol.II"
    new "Libro de auto ayuda Vol.II"

    # game/definitions.rpy:391
    old "Second iteration of the book written by a multi millionaire CEO about how to put your life together (According to him)."
    new "Segunda parte del ibro escrito por un CEO multimillonetis sobre como tomar las riendas de tu vida y hacerse a uno mismo (Según el)."

    # game/definitions.rpy:405
    old "Self Help Book Vol.III"
    new "Libro de auto ayuda Vol.III"

    # game/definitions.rpy:405
    old "Third iteration of the book written by a multi millionaire CEO about how to put your life together (According to him)."
    new "Tercera parte del ibro escrito por un CEO multimillonetis sobre como tomar las riendas de tu vida y hacerse a uno mismo (Según el)."

    # game/definitions.rpy:420
    old "Lifestopper"
    new "Lifestopper"

    # game/definitions.rpy:420
    old "A guy transforms into a monster and fights to hide his secret. When the academy's most popular girl discovers the truth, she becomes intrigued by him. But is her interest genuine, or is there a darker motive behind her perfect facade?"
    new "Un chico que se transforma en monstruo lucha por mantenerlo en secreto. Cuando la chica más popular de su academia descubre la verdad, esta se empieza a interesar por él. Pero ¿Son sus intenciones tan puras como su apariencia?."

    # game/definitions.rpy:434
    old "Lifestopper 2"
    new "Lifestopper 2"

    # game/definitions.rpy:434
    old "Years after being torn apart, two childhood friends cross paths again. Both struggle to keep their darkest secrets hidden, terrified that the truth might turn their reunion into hatred."
    new "Años después de ser separados, dos amigos de la infancia cruzan sus caminos de nuevo. Ambos tratan de mantener sus secretos más oscuros ocultos, aterrados de que la verdad transforme su reunión en odio."

    # game/definitions.rpy:448
    old "Lifestopper 3"
    new "Lifestopper 3"

    # game/definitions.rpy:448
    old "Two girls find themselves as roommates at one of the country's most prestigious academies. Bonded by a shared fascination with the occult, they grow closer until their connection eventually turns romantic."
    new "Doos chicas acaban siendo compañeras de habitación en la academia más prestigiosa del país. Unidas por su fascinación mutua por el ocultismo, ellas se hacen mas cercanas hasta que su conexion se convierte en romance."

    # game/definitions.rpy:463
    old "Basics On Human Mutation"
    new "Mutación Humana Para Catetos"

    # game/definitions.rpy:463
    old "Scientific book written by an influential scientific figure."
    new "Libro científico escrito por una figura influyente en el campo."

    # game/definitions.rpy:477
    old "Basics On Human Mutation Vol.II"
    new "Mutación Humana Para Catetos Vol.II"

    # game/definitions.rpy:477
    old "Part two of the scientific book written by an influential scientific figure."
    new "Parte dos del científico escrito por una figura influyente en el campo."

    # game/definitions.rpy:490
    old "Basics On Human Mutation Vol.III"
    new "Mutación Humana Para Catetos Vol.III"

    # game/definitions.rpy:490
    old "Part three of the scientific book written by an influential scientific figure."
    new "Parte tres del científico escrito por una figura influyente en el campo."

    # game/definitions.rpy:506
    old "The Godmother"
    new "La Madrina"

    # game/definitions.rpy:506
    old "The story of a man who joined the most powerful mafia family in the country as he tries to build his own path in life."
    new "La historia de un hombre que se unió a la familia mafiosa más poderosa del pais mientras trata de construir su camino en la vida."

    # game/definitions.rpy:519
    old "The Godmother 2"
    new "La Madrina 2"

    # game/definitions.rpy:519
    old "The story of a woman who joined the mafia after having to fake her own death and leave her life behind to get revenge on one of her former teammates, the wealthy heir of the organization she used to work for."
    new "La historia de una mujer que se unió a la mafia teniendo que fingir su propia muerte y dejar su vida atrás para cobrar su venganza sobre un antiguo miembro de su equipo. El hijo heredero de la organización para la que trabajaba."

    # game/definitions.rpy:532
    old "The Godmother 3"
    new "La Madrina 3"

    # game/definitions.rpy:532
    old "The story of how the mafia boss became the leader of the family, all the hardships she had to go through and an insight on her mindset."
    new "La historia sobre como la jefa de la mafia llegó a ser la lider de la familia, todas las dificultades por las que pasó y un vistazo a como funciona su mente."

    # game/definitions.rpy:320
    old "Contact Lenses"
    new "Lentillas"

    # game/definitions.rpy:320
    old "Use them to take off his glasses."
    new "Usalas para quitarle las gafas."

    # game/definitions.rpy:349
    old "stamina"
    new "estamina"

    # game/definitions.rpy:362
    old "hours"
    new "horas"

    # game/definitions.rpy:377
    old "confidence"
    new "confianza"

    # game/definitions.rpy:377
    old "intelligence"
    new "inteligencia"

    # game/definitions.rpy:420
    old "charm"
    new "encanto"

    # game/definitions.rpy:420
    old "hatefulness"
    new "odio"

    # game/definitions.rpy:506
    old "guts"
    new "agallas"

