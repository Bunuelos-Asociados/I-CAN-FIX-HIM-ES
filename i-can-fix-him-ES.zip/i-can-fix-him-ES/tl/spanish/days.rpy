﻿
# game/days.rpy:5
translate spanish day_2_b00893ee:

    # centered "Day 2"
    centered "Día 2"

# game/days.rpy:10
translate spanish day_2_7f47322f:

    # mc "So first day cleared, huh?"
    mc "Asi que primer dia completado, ¿Eh?"

# game/days.rpy:11
translate spanish day_2_6de6e8d0:

    # mc "I hope the scrawny little shit doesn't back down now."
    mc "Espero que el mierdecilla no se eche atrás ahora."

# game/days.rpy:12
translate spanish day_2_252e0253:

    # mc "It would suck to wait for another idiot to catch the bait..."
    mc "Sería una putada tener que esperar a que otro panoli pille el anzuelo..."

# game/days.rpy:15
translate spanish day_2_7d8afbe4:

    # "You received a notification."
    "Has recibido una notificación."

# game/days.rpy:17
translate spanish day_2_05500ff6:

    # mc "Huh?"
    mc "¿Eh?"

# game/days.rpy:21
translate spanish day_2_da9c7e81:

    # mf_nvl "Hi master!![cat]"
    mf_nvl "Hola, maestro!![cat]"

# game/days.rpy:22
translate spanish day_2_5084d53c:

    # mf_nvl "Yesterday was so much fun! I can already feel the results within me![cat]"
    mf_nvl "¡Ayer me lo pasé muy bien! Ya empiezo a sentir los resultados![cat]"

# game/days.rpy:24
translate spanish day_2_cf8ae24c:

    # mc "Looks like this scrawny ass is ready to pay more... {p}Hehehehe..."
    mc "Parece que el mierdecilla está listo para apoquinar mas... {p}Jejejeje..."

# game/days.rpy:26
translate spanish day_2_929f7c4e:

    # mc "I love the smell of money in the mornings."
    mc "Me encanta el olor a guita por las mañanas."

# game/days.rpy:30
translate spanish day_2_7d453f3f:

    # mc_nvl "Did you get enough rest?"
    mc_nvl "¿Has descansado bien?"

# game/days.rpy:31
translate spanish day_2_202514c2:

    # mc_nvl "Yesterday was pretty tough."
    mc_nvl "Lo de ayer fue durillo."

# game/days.rpy:32
translate spanish day_2_b1270b77:

    # mf_nvl "Please don't worry about me, master![cat]"
    mf_nvl "¡Porfa, no te preocupes por mi, maestro![cat]"

# game/days.rpy:33
translate spanish day_2_cd4e3a84:

    # mf_nvl "I'm ready to sufer as long as i get to stop being an insignificant loser someday :3[cat]"
    mf_nvl "Estoy listo para sufrir siempre y cuando algun dia deje de ser un perdedor insignificante :3[cat]"

# game/days.rpy:34
translate spanish day_2_120b157a:

    # mc_nvl "Did you just use \":3\"?"
    mc_nvl "¿Acabas de usar \":3\"?"

# game/days.rpy:35
translate spanish day_2_50a4bae3:

    # mf_nvl "Yes! it gives me a certain spark don't you think? :3333[cat]"
    mf_nvl "¡Si! Me da una cierta chispa, ¿No crees? :3333[cat]"

# game/days.rpy:38
translate spanish day_2_a8a76036:

    # mc_nvl "You do you I guess..."
    mc_nvl "Lo que tu digas, supongo..."

# game/days.rpy:42
translate spanish day_2_0e5936c6:

    # mc_nvl "It's kinda cute ngl."
    mc_nvl "Es bastante cuqui, la verdad."

# game/days.rpy:43
translate spanish day_2_b61403e9:

    # mf_nvl "Really? owo[cat]"
    mf_nvl "¿En serio? owo[cat]"

# game/days.rpy:44
translate spanish day_2_cf335264:

    # mf_nvl "I'm so glad you think so.[cat]"
    mf_nvl "Me alegra mucho que lo pienses.[cat]"

# game/days.rpy:45
translate spanish day_2_dbcef1f9:

    # mf_nvl "I'll make sure to use it more often!![cat]"
    mf_nvl "¡¡Me aseguraré de usarlo más a menudo!![cat]"

# game/days.rpy:47
translate spanish day_2_3a0b8720:

    # mc_nvl "Yeah, whatever makes you happy."
    mc_nvl "Ya, si te hace feliz adelante."

# game/days.rpy:49
translate spanish day_2_73e43ef4:

    # mc_nvl "Let's start today's routine."
    mc_nvl "Empecemos con la rutina de hoy."

# game/days.rpy:50
translate spanish day_2_6fa38ea9:

    # mf_nvl "Yes, sir!![cat]"
    mf_nvl "¡¡Si, señor!![cat]"

# game/days.rpy:53
translate spanish day_2_d41d8cd9:

    # nvl clear
    nvl clear

# game/days.rpy:56
translate spanish day_2_82947ecb:

    # centered "Coaching START"
    centered "¡Empieza el coaching!"

# game/days.rpy:65
translate spanish day_3_2ca901af:

    # centered "Day 3"
    centered "Día 3"

# game/days.rpy:70
translate spanish day_3_73ff0ebd:

    # mc "Looks like he's being serious about all this coaching bullshit."
    mc "Parece que se esta tomando en serio esta mierda del coaching."

# game/days.rpy:71
translate spanish day_3_7c804f34:

    # mc "As long as he keeps paying it will all be worth it."
    mc "Mientras me siga pagando merecerá la pena."

# game/days.rpy:72
translate spanish day_3_cb1ec756:

    # mc "Just five more days until it's over..."
    mc "Solo cinco dias más hasta que esto se acabe..."

# game/days.rpy:73
translate spanish day_3_5b83cf77:

    # mc "Not gonna lie, coaching this guy it's been kind of fun so far."
    mc "No puedo mentir, Hacerle de coach a este chico ha sido divertido de momento."

# game/days.rpy:77
translate spanish day_3_7d8afbe4:

    # "You received a notification."
    "Has recibido una notificación."

# game/days.rpy:79
translate spanish day_3_126dc1b5:

    # mc "Oh, he woke up. Finally."
    mc "Oh, se ha despertado. Por fin."

# game/days.rpy:83
translate spanish day_3_477b0bc8:

    # mf_nvl "Good morning, master![cat]"
    mf_nvl "¡Buenos días, maestro![cat]"

# game/days.rpy:84
translate spanish day_3_27f208da:

    # mf_nvl "Today I had a dream about the man I'm going to become after this experience.[cat]"
    mf_nvl "Hoy he soñado con el hombre que seré después de esta experiencia.[cat]"

# game/days.rpy:85
translate spanish day_3_79ed7e0a:

    # mf_nvl "I was so cool and totally not a loser anymore![cat]"
    mf_nvl "¡Era genial y para nada un perdedor como ahora![cat]"

# game/days.rpy:86
translate spanish day_3_fae9eabc:

    # mf_nvl "I hope that dream becomes true.[cat]"
    mf_nvl "Espero que ese sueño se haga realidad.[cat]"

# game/days.rpy:90
translate spanish day_3_e0af5b7d:

    # mc "No... I can't say that to him right now even if i want to."
    mc "No... No puedo decirle eso ahora aunque quiera."

# game/days.rpy:91
translate spanish day_3_96ec5b30:

    # mc "I need him to stay dependant on this course so he keeps paying and i can save my ass from the loan shark."
    mc "Necesito que dependa de este curso para que me siga pagando y así podre salvar mi culo del prestamista."

# game/days.rpy:95
translate spanish day_3_4b15e3d6:

    # mc_nvl "That dream will become true eventually"
    mc_nvl "Ese sueño se hará realidad algún día."

# game/days.rpy:96
translate spanish day_3_11d98649:

    # mc_nvl "As long as you keep paying for the course, obviously."
    mc_nvl "Siempre y cuando sigas pagando por este curso, claro."

# game/days.rpy:97
translate spanish day_3_56b75eef:

    # mf_nvl "I'm willing to do anything![cat]"
    mf_nvl "¡Estoy dispuesto a hacer lo que sea![cat]"

# game/days.rpy:98
translate spanish day_3_7d7d0011:

    # mf_nvl "So please don't give up on me, master![cat]"
    mf_nvl "¡Así que por favor no te rindas conmigo, maestro![cat]"

# game/days.rpy:99
translate spanish day_3_df1fc71c:

    # mc_nvl "Okay then."
    mc_nvl "Vale entonces."

# game/days.rpy:100
translate spanish day_3_5193f093:

    # mc_nvl "Let's get started!"
    mc_nvl "¡Hora de empezar!"

# game/days.rpy:101
translate spanish day_3_d8fa4caf:

    # mf_nvl "Yeah![cat]"
    mf_nvl "¡Si![cat]"

# game/days.rpy:102
translate spanish day_3_ecbe2930:

    # nvl clear
    # mc "You better not give up on me either, four eyes..."
    nvl clear
    mc "Más te vale no rendirte conmigo tampoco, cuatro ojos..."

# game/days.rpy:106
translate spanish day_3_82947ecb:

    # centered "Coaching START"
    centered "¡Empieza el coaching!"

# game/days.rpy:114
translate spanish day_4_036974af:

    # centered "Day 4"
    centered "Día 4"

# game/days.rpy:119
translate spanish day_4_dffab897:

    # mc "*Yawns loudly*"
    mc "*Bosteza fuerte*"

# game/days.rpy:120
translate spanish day_4_7aa78c5b:

    # mc "Ah, another day another dollar..."
    mc "Ah, otro dia otro dolar..."

# game/days.rpy:121
translate spanish day_4_5630dcd1:

    # mc "Let's see if [mf_name] is awake yet."
    mc "Veamos si [mf_name] se ha despertado ya."

# game/days.rpy:127
translate spanish day_4_05500ff6:

    # mc "Huh?"
    mc "¿Eh?"

# game/days.rpy:129
translate spanish day_4_243628a9:

    # go "OPEN UP, [mc_name!u]!"
    go "¡ABRE AHORA MISMO, [mc_name!u]!"

# game/days.rpy:130
translate spanish day_4_516632e6:

    # go "WE CAME TO COLLECT THE MONEY!"
    go "¡HEMOS VENIDO A POR LA PASTA!"

# game/days.rpy:133
translate spanish day_4_10e73291:

    # mc "Oh shit!!"
    mc "¡¡Mierda!!"

# game/days.rpy:134
translate spanish day_4_af10e9dc:

    # mc "I-I need to stay silent and hide..."
    mc "N-Necesito mantenerme en silencio y esconderme..."

# game/days.rpy:135
translate spanish day_4_6902a158:

    # mc "Don't breathe, don't breathe, don't breate..."
    mc "No respires, no respires, no respires..."

# game/days.rpy:138
translate spanish day_4_7d8afbe4:

    # "You received a notification."
    "Has recibido una notificación."

# game/days.rpy:140
translate spanish day_4_721f2d3f:

    # mc "Shit, not now!"
    mc "Joder, ¡Ahora no!"

# game/days.rpy:142
translate spanish day_4_1ee2d887:

    # go "WHAT THE FUCK WAS THAT NOISE?"
    go "¿QUÉ COJONES HA SIDO ESE RUIDO?"

# game/days.rpy:143
translate spanish day_4_8eea7192:

    # go "WE KNOW YOU'RE IN THERE!"
    go "¡SABEMOS QUE ESTAS EN CASA!"

# game/days.rpy:147
translate spanish day_4_477b0bc8:

    # mf_nvl "Good morning, master![cat]"
    mf_nvl "¡Buenos dias, maestro![cat]"

# game/days.rpy:148
translate spanish day_4_f9271c2a:

    # mf_nvl "Did you sleep well?[cat]"
    mf_nvl "¿Has dormido bien?[cat]"

# game/days.rpy:150
translate spanish day_4_163aa604:

    # mc "Fuck, I need to cut the convo short until those fuckers leave..."
    mc "Mierda, necesito cortar pronto la conversación hasta que esos cabronazos se piren..."

# game/days.rpy:154
translate spanish day_4_ed31c565:

    # mc_nvl "I'm kind of busy right now."
    mc_nvl "Estoy algo ocupadete ahora mismo."

# game/days.rpy:155
translate spanish day_4_284a195f:

    # mc_nvl "You, know. Preparing today's routine and all that jazz."
    mc_nvl "Ya sabes. Preparando la rutina de hoy y todo eso."

# game/days.rpy:156
translate spanish day_4_64d7dd25:

    # mf_nvl "Oh, I see![cat]"
    mf_nvl "¡Ah, ya veo![cat]"

# game/days.rpy:157
translate spanish day_4_fab6ad4b:

    # mf_nvl "You work so hard, [mc_name], it's impressive![cat]"
    mf_nvl "Trabajas muy duro, [mc_name], ¡Es impresionante![cat]"

# game/days.rpy:158
translate spanish day_4_b4249014:

    # mf_nvl "Let me know when you're available to start![cat]"
    mf_nvl "¡Dame un toque cuando estés listo para empezar![cat]"

# game/days.rpy:160
translate spanish day_4_5a2a8288:

    # mc "Ah, thank god..."
    mc "Ah, menos mal..."

# game/days.rpy:161
translate spanish day_4_30fc10db:

    # mc "Now I need to hide until they leave..."
    mc "Ahora necesito esconderme hasta que se vayan..."

# game/days.rpy:164
translate spanish day_4_3a939766:

    # "You hide under your bed for half an hour."
    "Te escondes debajo de tu cama por media hora."

# game/days.rpy:166
translate spanish day_4_b22d0178:

    # go "Fuck, looks like the fucker it's not at home. Let's come back next week."
    go "Mierda, parece que el gilipollas no está en casa. Volvamos la semana que viene."

# game/days.rpy:170
translate spanish day_4_6de7b42a:

    # mc "Thank fuck..."
    mc "Joder, gracias al cielo..."

# game/days.rpy:171
translate spanish day_4_18bbf766:

    # mc "I thought I was going to die..."
    mc "Pensaba que esta no la contaba..."

# game/days.rpy:172
translate spanish day_4_eb0bd19f:

    # mc "I need to talk to [mf_name] or else he'll start growing suspicious of me."
    mc "Necesito hablar con [mf_name] antes de que empiece a sospechar de mi."

# game/days.rpy:175
translate spanish day_4_5f3bf40d:

    # mc_nvl "Hey, I'm ready to start now."
    mc_nvl "Hey, todo listo para empezar."

# game/days.rpy:176
translate spanish day_4_a56cc2be:

    # mf_nvl "Yay! Let's get started![cat]"
    mf_nvl "¡Guay! ¡Empecemos pues!"

# game/days.rpy:177
translate spanish day_4_d41d8cd9:

    # nvl clear
    nvl clear

# game/days.rpy:181
translate spanish day_4_82947ecb:

    # centered "Coaching START"
    centered "¡Empieza el coaching!"

# game/days.rpy:191
translate spanish day_5_555c2f03:

    # centered "Day 5"
    centered "Día 5"

# game/days.rpy:198
translate spanish day_5_c8a09a12:

    # mc "I've been thinking all night about what [mf_name] said to me yesterday..."
    mc "He estado pensando toda la noche sobre lo que me dijo [mf_name] ayer..."

# game/days.rpy:199
translate spanish day_5_e867b517:

    # mc "I think it was so"
    mc "Pienso que fue"

# game/days.rpy:203
translate spanish day_5_bfeb51ab:

    # mc "I think it was so sweet..."
    mc "Pienso que fue muy dulce..."

# game/days.rpy:204
translate spanish day_5_bfbcf711:

    # mc "Fuck, WHY AM I THINKING THAT OF ANOTHER GUY???"
    mc "Joder, ¿¿¿POR QUE PIENSO ESO DE OTRO TIO???"

# game/days.rpy:205
translate spanish day_5_50c9f7d8:

    # mc "I need to cool down before I start going soft on him..."
    mc "Necesito despejarme antes de que me vuelva blando con el..."

# game/days.rpy:208
translate spanish day_5_3adc02a2:

    # mc "I think it was so fucking CRINGE of him."
    mc "Pienso que fue CRINGE QUE SE CAGA LA PERRA."

# game/days.rpy:209
translate spanish day_5_ea127e94:

    # mc "Then again, I couldn't expect less from him."
    mc "Aunque tampoco podria esperar otra cosa de este fulano."

# game/days.rpy:213
translate spanish day_5_b4e386b6:

    # mc "I wonder what he wanted to talk about yesterday."
    mc "Me pregunto sobre qué querría hablar ayer."

# game/days.rpy:214
translate spanish day_5_8ecb33ba:

    # mc "Maybe he want me to go easier on him?"
    mc "¿Tal vez quiere que le de cuartelillo?"

# game/days.rpy:215
translate spanish day_5_67da4ccc:

    # mc "Nah, I don't think that's the case."
    mc "No, no creo que sea eso."

# game/days.rpy:217
translate spanish day_5_0fe99f4d:

    # mc "Everything's going according to the plan."
    mc "Todo va según el plan."

# game/days.rpy:218
translate spanish day_5_ddadcdc1:

    # mc "Soon enough I'll have enough money to pay the loan shark. I just need to push harder."
    mc "Muy pronto tendre suficiente guita para pagarle al prestamista. Solo necesito darle más caña."

# game/days.rpy:222
translate spanish day_5_7d8afbe4:

    # "You received a notification."
    "Has recibido una notificación."

# game/days.rpy:224
translate spanish day_5_2b54697c:

    # mc "Oh, he's awake."
    mc "Ah, se ha despertado."

# game/days.rpy:226
translate spanish day_5_d41d8cd9:

    # nvl clear
    nvl clear

# game/days.rpy:229
translate spanish day_5_539c8c7a:

    # mf_nvl "Hiya! I'm ready to start the day![cat]"
    mf_nvl "¡Holi! ¡Estoy listo para empezar el día![cat]"

# game/days.rpy:230
translate spanish day_5_3041eb00:

    # mf_nvl "In fact today I made a special breakfast.[cat]"
    mf_nvl "De hecho hoy me he preparado un desayuno especial.[cat]"

# game/days.rpy:231
translate spanish day_5_6ddb59b7:

    # mf_nvl "{image=breakfast_photo.png}"
    mf_nvl "{image=breakfast_photo.png}"

# game/days.rpy:232
translate spanish day_5_6b4895ac:

    # mf_nvl "Just made some bullshiiiiit[cat]"
    mf_nvl "Hice tremendo mierdóóóóóóóóón[cat]"

# game/days.rpy:236
translate spanish day_5_580f151c:

    # mc_nvl "What the FUCK is that??"
    mc_nvl "¿¿Que COJONES es eso??"

# game/days.rpy:237
translate spanish day_5_6cd8229f:

    # mf_nvl "You know, a protein boost![cat]"
    mf_nvl "Ya sabes, ¡Un chute de proteína![cat]"

# game/days.rpy:238
translate spanish day_5_5e63effe:

    # mf_nvl "I used everything I had that was about to expire.[cat]"
    mf_nvl "Usé todo lo que tenía que estaba a punto de caducar.[cat]"

# game/days.rpy:239
translate spanish day_5_4274f508:

    # mf_nvl "Is this how domestic economy works, right?[cat]"
    mf_nvl "Así es como funciona la economía doméstica, ¿Verdad?[cat]"

# game/days.rpy:243
translate spanish day_5_6145b709:

    # mc_nvl "Kinda."
    mc_nvl "Algo así."

# game/days.rpy:244
translate spanish day_5_19cd28e7:

    # mf_nvl "See? I'm making progress here![cat]"
    mf_nvl "¿Ves? ¡Estoy progresando y todo![cat]"

# game/days.rpy:246
translate spanish day_5_599c5001:

    # mc_nvl "Not quite."
    mc_nvl "No del todo."

# game/days.rpy:247
translate spanish day_5_deca600f:

    # mf_nvl "Oh, I still have a lot to learn then![cat]"
    mf_nvl "Vaya, ¡Aún tengo mucho que aprender entonces![cat]"

# game/days.rpy:252
translate spanish day_5_8ec97089:

    # mc_nvl "Save some for me."
    mc_nvl "Guarda un poco para mi."

# game/days.rpy:253
translate spanish day_5_7c27748a:

    # mf_nvl "Sure! I hope you can come by someday.[cat]"
    mf_nvl "¡Claro! Espero que algún dia puedas pasarte por aqui.[cat]"

# game/days.rpy:254
translate spanish day_5_44887316:

    # mf_nvl "That would be so cool.[cat]"
    mf_nvl "Eso sería genial.[cat]"

# game/days.rpy:255
translate spanish day_5_3a353192:

    # mf_nvl "I could show you my figurine collection.[cat]"
    mf_nvl "Podría enseñarte mi colección de figuritas.[cat]"

# game/days.rpy:256
translate spanish day_5_af2de426:

    # mf_nvl "By the way, [mc_name][cat]"
    mf_nvl "Por cierto, [mc_name][cat]"

# game/days.rpy:257
translate spanish day_5_5c0db23b:

    # mf_nvl "Do you have any hobbies?[cat]"
    mf_nvl "Tienes algún hobby?[cat]"

# game/days.rpy:258
translate spanish day_5_3a2af0fa:

    # mf_nvl "We always talk about the coaching routine but I kinda wanna know more about you.[cat]"
    mf_nvl "Siempre hablamos sobre la rutina de coaching pero me gustaria conocerte un poco más.[cat]"

# game/days.rpy:260
translate spanish day_5_2fe6dde2:

    # mc "He wants to know more about me?"
    mc "¿Quiere conocerme un poco más?"

# game/days.rpy:261
translate spanish day_5_e4cf6a01:

    # mc "I guess it makes sense... We're spending a lot of time together since we started with the coaching thing."
    mc "Supongo que tiene sentido... Estamos pasando mucho tiempo juntos desde que empezamos con lo del coaching."

# game/days.rpy:262
translate spanish day_5_c03ec570:

    # mc "He wants to know about my hobby, huh? Let me think..."
    mc "Quiere saber cual es mi hobby, ¿Eh? Dejame pensar..."

# game/days.rpy:265
translate spanish day_5_ada6595d:

    # mc_nvl "I guess my hobby is [mc_hobby]."
    mc_nvl "Supongo que mi hobby es [mc_hobby]."

# game/days.rpy:266
translate spanish day_5_c8af5803:

    # mf_nvl "[mc_hobby], huh? That's neat![cat]"
    mf_nvl "[mc_hobby], ¿Eh? Está muy guay![cat]"

# game/days.rpy:267
translate spanish day_5_5499ad77:

    # mf_nvl "Perhaps you can teach me about it someday after the coaching course![cat]"
    mf_nvl "Tal vez podrias enseñarme sobre [mc_hobby] algún día después del coaching![cat]"

# game/days.rpy:268
translate spanish day_5_ce890658:

    # mf_nvl "Oh, and don't worry. I'll make sure to pay for the class.[cat]"
    mf_nvl "Ah, y no te preocupes. Me aseguraré de pagarte por las clases.[cat]"

# game/days.rpy:273
translate spanish day_5_9690815c:

    # mc_nvl "There's no need to pay."
    mc_nvl "No es necesario pagar."

# game/days.rpy:274
translate spanish day_5_6cd4c8ec:

    # mc_nvl "In fact, I'll be glad to share my hobby with you."
    mc_nvl "De hecho me encantaría compartir mi hobby contigo."

# game/days.rpy:275
translate spanish day_5_c1e10afc:

    # mf_nvl "That's so awesome![cat]"
    mf_nvl "¡Eso es genial![cat]"

# game/days.rpy:276
translate spanish day_5_0c8a026a:

    # mf_nvl "I can't wait to [mc_hobby] together![cat]"
    mf_nvl "¡No puedo esperar a [mc_hobby] juntos![cat]"

# game/days.rpy:279
translate spanish day_5_e241f3de:

    # mc_nvl "I'll take you up on that offer."
    mc_nvl "Te tomo la palabra."

# game/days.rpy:280
translate spanish day_5_b7809c90:

    # mf_nvl "Yay! I can't wait![cat]"
    mf_nvl "¡Yay! ¡No puedo esperar![cat]"

# game/days.rpy:282
translate spanish day_5_2b459ce8:

    # mc_nvl "Well, enough chatter."
    mc_nvl "Bueno, suficiente cháchara."

# game/days.rpy:283
translate spanish day_5_b824a61e:

    # mc_nvl "Let's start the day!"
    mc_nvl "Empecemos con el día!"

# game/days.rpy:284
translate spanish day_5_d8fa4caf:

    # mf_nvl "Yeah![cat]"
    mf_nvl "¡Si![cat]"

# game/days.rpy:285
translate spanish day_5_d41d8cd9_1:

    # nvl clear
    nvl clear

# game/days.rpy:289
translate spanish day_5_82947ecb:

    # centered "Coaching START"
    centered "¡Empieza el coaching!"

# game/days.rpy:298
translate spanish day_6_e4d448d9:

    # centered "Day 6"
    centered "Día 6"

# game/days.rpy:303
translate spanish day_6_e7a26b23:

    # mc "*Yawns*"
    mc "*Bosteza*"

# game/days.rpy:304
translate spanish day_6_d1ddcbbc:

    # mc "A new day starts..."
    mc "Empieza un nuevo día..."

# game/days.rpy:305
translate spanish day_6_a9de1514:

    # mc "I can't believe tomorrow's the last day..."
    mc "No me puedo creer que mañana sea el último día..."

# game/days.rpy:306
translate spanish day_6_2055f5a8:

    # mc "I'm gonna miss that four eyes."
    mc "Echaré de menos a ese gafotas."

# game/days.rpy:308
translate spanish day_6_f8ff8903:

    # mc "HUH? WHAT DID I JUST SAID? {p}MISS THAT CRINGEY ASS IDIOT?"
    mc "¿QUE? ¿QUE HOSTIAS ACABO DE DECIR? {p}¿ECHAR DE MENOS A ESE PANOLI?"

# game/days.rpy:310
translate spanish day_6_5a571fb4:

    # mc "Nevermind, maybe it's because of stress."
    mc "Ni caso, será cosa del estrés."

# game/days.rpy:311
translate spanish day_6_9b8e8a96:

    # mc "But stil..."
    mc "Aun así..."

# game/days.rpy:312
translate spanish day_6_c7ee01b9:

    # mc "This week is being so much fun."
    mc "Esta semana está siendo muy divertida."

# game/days.rpy:315
translate spanish day_6_2d716851:

    # mc "I wonder if he woke up already."
    mc "Me pregunto si se habrá despertado ya."

# game/days.rpy:316
translate spanish day_6_9a82622d:

    # mc "I wonder what kind of bullshit he made for breakfast."
    mc "Me pregunto que clase de mierdón nefasto se habrá hecho para desayunar."

# game/days.rpy:317
translate spanish day_6_c3614815:

    # mc "Fuck, listen to me. I'm supposed to not get attatched and just take the money."
    mc "Joder, no hay mas que escucharme. Se supone que solo debería importarme la pasta."

# game/days.rpy:320
translate spanish day_6_7d8afbe4:

    # "You received a notification."
    "Has recibido una notificación."

# game/days.rpy:324
translate spanish day_6_7fc92b97:

    # mf_nvl "Good morning![cat]"
    mf_nvl "¡Buenos días![cat]"

# game/days.rpy:325
translate spanish day_6_1142f9d2:

    # mf_nvl "I'm sorry I'm late today.[cat]"
    mf_nvl "Siento llegar tarde hoy.[cat]"

# game/days.rpy:326
translate spanish day_6_cb948bae:

    # mf_nvl "I had a little accident in the kitchen today...[cat]"
    mf_nvl "He tenido un pequeño accidente en la cocina hoy...[cat]"

# game/days.rpy:329
translate spanish day_6_1d2ce1f3:

    # mc_nvl "Are you okay??"
    mc_nvl "¿¿Estás bien??"

# game/days.rpy:330
translate spanish day_6_8569b8d0:

    # mf_nvl "Yeah, please dont worry about me![cat]"
    mf_nvl "¡Si, porfa no te preocupes por mi![cat]"

# game/days.rpy:332
translate spanish day_6_d08ce287:

    # mf_nvl "{image=kitchenaccident_photo.png}"
    mf_nvl "{image=kitchenaccident_photo.png}"

# game/days.rpy:333
translate spanish day_6_5a8b033b:

    # mf_nvl "See? Totally fine![cat]"
    mf_nvl "¿Ves? ¡Ni un rasguño![cat]"

# game/days.rpy:334
translate spanish day_6_fc652104:

    # mf_nvl "Just need to clean myself up a bit.[cat]"
    mf_nvl "Solo necesito limpiarme un poco.[cat]"

# game/days.rpy:340
translate spanish day_6_c7b12666:

    # mc_nvl "Is that an angel I'm seeing?"
    mc_nvl "¿Es un ángel eso que veo?"

# game/days.rpy:341
translate spanish day_6_cd9cf056:

    # mf_nvl "AN ANGEL??? WHERE????[cat]"
    mf_nvl "¿¿¿UN ÁNGEL??? ¿¿¿¿DÓNDE????[cat]"

# game/days.rpy:342
translate spanish day_6_a3b7e9f1:

    # mc "Oh my god, he's completely clueless..."
    mc "Ay, señor. Esta en la higuera..."

# game/days.rpy:345
translate spanish day_6_2ef1c965:

    # mc_nvl "I was talking bout you. You're pretty."
    mc_nvl "Hablaba sobre ti. Eres adorable."

# game/days.rpy:346
translate spanish day_6_e06f8a7e:

    # mf_nvl "W-What??[cat]"
    mf_nvl "¿¿Q-QUE??[cat]"

# game/days.rpy:347
translate spanish day_6_ac8ed760:

    # mf_nvl "Are you teasing me, [mc_name]?...[cat]"
    mf_nvl "¿Te estás burlando de mi, [mc_name]?...[cat]"

# game/days.rpy:348
translate spanish day_6_43f276fd:

    # mf_nvl "I mean, I know i'm not the pinacle of masculinity yet but...[cat]"
    mf_nvl "Quiero decir, ya se que no soy el pinaculo de la masculinidad aún pero...[cat]"

# game/days.rpy:349
translate spanish day_6_c321b319:

    # mf_nvl "I hope someday you'd call me \"handsome\" rather than \"pretty\".[cat]"
    mf_nvl "Me gustaría que algún dia usases \"genial\" para describirme en vez de \"adorable\".[cat]"

# game/days.rpy:350
translate spanish day_6_7ddc8bb5:

    # mf_nvl "I-I mean if YOU want to, of course![cat]"
    mf_nvl "E-Es decir, ¡Solo si TÚ quieres, claro![cat]"

# game/days.rpy:351
translate spanish day_6_3d4df83a:

    # mc_nvl "We'll see about that."
    mc_nvl "Ya veremos."

# game/days.rpy:353
translate spanish day_6_7e1d77aa:

    # mc_nvl "Forget it."
    mc_nvl "Olvidalo."

# game/days.rpy:356
translate spanish day_6_6eeaf899:

    # mc_nvl "I'm glad you're fine."
    mc_nvl "Me alegro de que estés bien."

# game/days.rpy:357
translate spanish day_6_be94be3c:

    # mc_nvl "I was getting worried for a second."
    mc_nvl "Me había preocupado por un momento."

# game/days.rpy:358
translate spanish day_6_0d18d1bd:

    # mf_nvl "Oh, I'm sorry about that![cat]"
    mf_nvl "Ay, ¡Perdoname, no era mi intención![cat]"

# game/days.rpy:362
translate spanish day_6_37cd51ca:

    # mc_nvl "Holy shit warn a guy before a jumpscare."
    mc_nvl "Ayer cagué algo parecido."

# game/days.rpy:363
translate spanish day_6_c0f1adee:

    # mf_nvl "S-SORRY, MASTER! I WON'T SHOW MY UGLY MUG UNLESS YOU ASK ME TO, MASTER![cat]"
    mf_nvl "¡P-PERDÓN, MAESTRO! ¡NO VOLVERÉ A ENSEÑAR EL JETO A NO SER QUE ME LO PIDAS, MAESTRO![cat]"

# game/days.rpy:365
translate spanish day_6_fc652104_1:

    # mf_nvl "Just need to clean myself up a bit.[cat]"
    mf_nvl "Solo necesito limpiarme un poco.[cat]"

# game/days.rpy:368
translate spanish day_6_dc0aa65f:

    # mc_nvl "Whatever."
    mc_nvl "Lo que sea."

# game/days.rpy:369
translate spanish day_6_f0c7142f:

    # mc_nvl "As long as you're ready for the coaching everything's fine."
    mc_nvl "Con tal de que estés listo para el coaching me la suda."

# game/days.rpy:372
translate spanish day_6_86c3f567:

    # mf_nvl "Oh..."
    mf_nvl "Oh.."

# game/days.rpy:373
translate spanish day_6_c5f36f1d:

    # mf_nvl "I-I guess you're right!"
    mf_nvl "¡S-supongo que tienes razón!"

# game/days.rpy:374
translate spanish day_6_7f811405:

    # mf_nvl "You shouldn't worry about me..."
    mf_nvl "No deberías preocuparte por mi..."

# game/days.rpy:375
translate spanish day_6_4ad4003c:

    # mc "Shit, I think he's upset..."
    mc "Mierda, creo que la he cagado..."

# game/days.rpy:377
translate spanish day_6_764387de:

    # mc_nvl "Anyway..."
    mc_nvl "En fin..."

# game/days.rpy:378
translate spanish day_6_0f4969dd:

    # mc_nvl "Are you ready for today's routine?"
    mc_nvl "¿Estás listo para la rutina de hoy?"

# game/days.rpy:379
translate spanish day_6_f0c5cf6e:

    # mf_nvl "Yes, master![cat]"
    mf_nvl "¡Si, maestro![cat]"

# game/days.rpy:381
translate spanish day_6_d41d8cd9:

    # nvl clear
    nvl clear

# game/days.rpy:386
translate spanish day_6_82947ecb:

    # centered "Coaching START"
    centered "¡Empieza el coaching!"

# game/days.rpy:395
translate spanish day_7_0d60eb93:

    # centered "Day 7 {p}Last day"
    centered "Día 7 {p}Último día"

# game/days.rpy:400
translate spanish day_7_a144a4ce:

    # mc "It's the last day already..."
    mc "Ya es el último día..."

# game/days.rpy:403
translate spanish day_7_afe2e60d:

    # mc "I can't believe I'm going to lose him..."
    mc "No me puedo creer que vaya a perderle..."

# game/days.rpy:404
translate spanish day_7_cf7d1b7a:

    # mc "SHIT! Where did that came from?????"
    mc "¡¡HOSTIAS!! ¿¿¿¿¿Y eso de dónde ha salido?????"

# game/days.rpy:405
translate spanish day_7_06374fc9:

    # mc "But lowkey it's kinda true..."
    mc "Pero lo cierto es que es bastante cierto..."

# game/days.rpy:408
translate spanish day_7_bada722b:

    # mc "I can't believe I'll be able to pay my debt."
    mc "No me puedo creer que vaya a poder pagar mi deuda."

# game/days.rpy:410
translate spanish day_7_b3e77af0:

    # mc "Anyway, let's see what he's up to."
    mc "En fin, Veamos en que anda ahora."

# game/days.rpy:411
translate spanish day_7_879f49ae:

    # mc "Maybe today I should be the one sending the first message of the day."
    mc "Tal vez ho debería ser yo el primero en mandar el mensaje."

# game/days.rpy:413
translate spanish day_7_d41d8cd9:

    # nvl clear
    nvl clear

# game/days.rpy:420
translate spanish day_7_14481a9f:

    # mc_nvl "Good morning, honey"
    mc_nvl "Buenos dias, cariño"

# game/days.rpy:421
translate spanish day_7_ed5ec09e:

    # mf_nvl "\"Honey\"?[cat]"
    mf_nvl "¿\"Cariño\"?[cat]"

# game/days.rpy:425
translate spanish day_7_c552bddc:

    # mc_nvl "Yes, honey?"
    mc_nvl "¿Si, cariño?"

# game/days.rpy:426
translate spanish day_7_70d3e28a:

    # mf_nvl "N-No, I-I mean...[cat]"
    mf_nvl "N-No, es decir...[cat]"

# game/days.rpy:427
translate spanish day_7_c2702e27:

    # mf_nvl "Did you just call me \"Honey\", [mc_name]?[cat]"
    mf_nvl "¿Acabas de llamarme \"Cariño\", [mc_name]?[cat]"

# game/days.rpy:431
translate spanish day_7_35f31faf:

    # mc_nvl "Yes."
    mc_nvl "Si."

# game/days.rpy:432
translate spanish day_7_c1cc2cf9:

    # mf_nvl "O-Oh.[cat]"
    mf_nvl "O-Oh.[cat]"

# game/days.rpy:433
translate spanish day_7_4d217f3d:

    # mf_nvl "I'm guessing this is part of the course.[cat]"
    mf_nvl "Supongo que es parte del curso.[cat]"

# game/days.rpy:438
translate spanish day_7_38a4cdbc:

    # mc_nvl "Did I made you feel uncomfortable?"
    mc_nvl "¿Te hice sentir incomodo?"

# game/days.rpy:439
translate spanish day_7_a14f6436:

    # mf_nvl "N-No! Not at all![cat]"
    mf_nvl "¡N-No! ¡Para nada![cat]"

# game/days.rpy:440
translate spanish day_7_9231772f:

    # mf_nvl "It was just a bit unexpected.[cat]"
    mf_nvl "Es solo que no me lo esperaba.[cat]"

# game/days.rpy:442
translate spanish day_7_8046dcdb:

    # mf_nvl "It's kinda sweet.[cat]"
    mf_nvl "Es bastante tierno.[cat]"

# game/days.rpy:445
translate spanish day_7_18d378f6:

    # mc_nvl "Good morning"
    mc_nvl "Buenos dias"

# game/days.rpy:446
translate spanish day_7_1ec7c6e4:

    # mf_nvl "Good morning, [mc_name]![cat]"
    mf_nvl "¡Buenos dias, [mc_name]![cat]"

# game/days.rpy:447
translate spanish day_7_e2b4e3f0:

    # mf_nvl "I see you anticipated my moves like the master you are! hehe[cat]"
    mf_nvl "¡Veo que has anticipado mis movimientos como el maestro que eres! jeje[cat]"

# game/days.rpy:450
translate spanish day_7_d098ade0:

    # mc_nvl "You should be awake by now, scum. Say good morning."
    mc_nvl "Deberías estar despierto a estas horas, cacho mierda. Di buenos dias."

# game/days.rpy:451
translate spanish day_7_60507f3d:

    # mf_nvl "YES, MASTER. SORRY, MASTER o7[cat]"
    mf_nvl "¡SI, MAESTRO! ¡LO SIENTO, MAESTRO! o7[cat]"

# game/days.rpy:454
translate spanish day_7_20bff470:

    # mc_nvl "Today's the last day."
    mc_nvl "Hoy es el último día."

# game/days.rpy:455
translate spanish day_7_4863c868:

    # mc_nvl "Did you sleep well?"
    mc_nvl "¿Has dormido bién?"

# game/days.rpy:456
translate spanish day_7_534eeb88:

    # mf_nvl "Yes! But i'm kinda sad it's gonna be over so soon...[cat]"
    mf_nvl "¡Si! Pero estoy algo triste de que esto se vaya a acabar tan pronto...[cat]"

# game/days.rpy:461
translate spanish day_7_7a78c602:

    # mc_nvl "Don't worry. We can stay in touch."
    mc_nvl "No te preocupes. Podemos mantenernos en contacto."

# game/days.rpy:462
translate spanish day_7_a409a260:

    # mf_nvl "I'm so glad to hear that, [mc_name]![cat]"
    mf_nvl "¡Me alegra mucho escuchar eso, [mc_name]![cat]"

# game/days.rpy:463
translate spanish day_7_e16ad3d2:

    # mf_nvl "Can't wait to show you more pics of my breakfast![cat]"
    mf_nvl "¡No puedo esperar a mandarte mas fotos de mis desayunos![cat]"

# game/days.rpy:469
translate spanish day_7_cdffcb18:

    # mc_nvl "I'll give you my address so you can come to visit."
    mc_nvl "Te daré mi dirección para que vengas a visitarme."

# game/days.rpy:470
translate spanish day_7_6b22329c:

    # mf_nvl "Really? Tat would make me so happy![cat]"
    mf_nvl "¿De verdad? ¡Eso me haría muy feliz![cat]"

# game/days.rpy:473
translate spanish day_7_0f0cd4e7:

    # mf_nvl "I can't wait to visit you and maybe cook breakfast for you someday.[cat]"
    mf_nvl "No puedo esperar a visitarte y hacerte el desayuno algún dia.[cat]"

# game/days.rpy:474
translate spanish day_7_17581a83:

    # mf_nvl "You're so amazing, [mc_name]![cat]"
    mf_nvl "¡Eres genial, [mc_name]![cat]"

# game/days.rpy:475
translate spanish day_7_8b1e29d3:

    # mf_nvl "In fact, I really like you...[cat]"
    mf_nvl "De hecho, Me gustas mucho...[cat]"

# game/days.rpy:476
translate spanish day_7_519c55b0:

    # mf_nvl "A-AH! F-Forget that last part, please![cat]"
    mf_nvl "¡A-AH! ¡O-Olvida esa ultima cosa, porfa![cat]"

# game/days.rpy:481
translate spanish day_7_ee5247c0:

    # mc_nvl "Okay, don't worry."
    mc_nvl "Vale, no te preocupes."

# game/days.rpy:485
translate spanish day_7_26a78352:

    # mc_nvl "Yeah, me too."
    mc_nvl "Si, yo también."

# game/days.rpy:486
translate spanish day_7_0fc6fce0:

    # mf_nvl "I'm gonna miss you, [mc_name].[cat]"
    mf_nvl "Te echaré de menos, [mc_name].[cat]"

# game/days.rpy:487
translate spanish day_7_dcc5229a:

    # mf_nvl "You've been an amazing coach![cat]"
    mf_nvl "¡Has sido un coach genial![cat]"

# game/days.rpy:490
translate spanish day_7_8b1e29d3_1:

    # mf_nvl "In fact, I really like you...[cat]"
    mf_nvl "De hecho, Me gustas mucho...[cat]"

# game/days.rpy:491
translate spanish day_7_519c55b0_1:

    # mf_nvl "A-AH! F-Forget that last part, please![cat]"
    mf_nvl "¡A-AH! ¡O-Olvida esa ultima cosa, porfa![cat]"

# game/days.rpy:496
translate spanish day_7_ee5247c0_1:

    # mc_nvl "Okay, don't worry."
    mc_nvl "Vale, no te preocupes."

# game/days.rpy:500
translate spanish day_7_554b9c52:

    # mc_nvl "There's no point in crying about it."
    mc_nvl "No tiene sentido lloriquear por eso ahora."

# game/days.rpy:501
translate spanish day_7_a4125500:

    # mf_nvl "Yeah, I guess you're right...[cat]"
    mf_nvl "S-Si, supongo que tienes razón...[cat]"

# game/days.rpy:503
translate spanish day_7_5fa5c5d2:

    # mf_nvl "I'm gonna miss you, though.[cat]"
    mf_nvl "Pero te echaré de menos.[cat]"

# game/days.rpy:505
translate spanish day_7_a0b8b4f1:

    # mf_nvl "I know it's selfish to ask but..."
    mf_nvl "Sé que es algo egoísta pero..."

# game/days.rpy:506
translate spanish day_7_9089d3fc:

    # mf_nvl "Please don't forget me?...[cat]"
    mf_nvl "¿Por favor no te olvides de mi?...[cat]"

# game/days.rpy:509
translate spanish day_7_77a9b43c:

    # mc_nvl "I could never forget you."
    mc_nvl "Jamás podria olvidarte."

# game/days.rpy:510
translate spanish day_7_aacf600d:

    # mf_nvl "Oh...[cat]"
    mf_nvl "Oh...[cat]"

# game/days.rpy:511
translate spanish day_7_da8775b6:

    # mf_nvl "That is actually so sweet.[cat]"
    mf_nvl "Eso es muy dilce de tu parte.[cat]"

# game/days.rpy:512
translate spanish day_7_ea26466d:

    # mf_nvl "Thank you <3"
    mf_nvl "Gracias <3"

# game/days.rpy:514
translate spanish day_7_063b7c4f:

    # mc_nvl "I wont."
    mc_nvl "No lo haré."

# game/days.rpy:515
translate spanish day_7_e55eed1e:

    # mf_nvl "Yay! That makes me feel better.[cat]"
    mf_nvl "¡Yay! Eso me hace sentir mejor.[cat]"

# game/days.rpy:517
translate spanish day_7_3e432ead:

    # mc_nvl "I already did."
    mc_nvl "Ya lo hice."

# game/days.rpy:518
translate spanish day_7_9f09fd05:

    # mf_nvl "You're a big meanie![cat]"
    mf_nvl "Eres muy malo![cat]"

# game/days.rpy:521
translate spanish day_7_e7ec153d:

    # mc_nvl "Anyway."
    mc_nvl "En fin."

# game/days.rpy:522
translate spanish day_7_dd3f2c1e:

    # mc_nvl "Let's get this over with!"
    mc_nvl "¡Terminemos con esto!"

# game/days.rpy:523
translate spanish day_7_d8fa4caf:

    # mf_nvl "Yeah![cat]"
    mf_nvl "¡Si![cat]"

# game/days.rpy:526
translate spanish day_7_d41d8cd9_1:

    # nvl clear
    nvl clear

# game/days.rpy:529
translate spanish day_7_82947ecb:

    # centered "Coaching START"
    centered "¡Empieza el coaching!"

translate spanish strings:

    # game/days.rpy:29
    old "Did you get enough rest?"
    new "¿Has descansado bien?"

    # game/days.rpy:37
    old "You do you I guess..."
    new "Lo que tu digas, supongo..."

    # game/days.rpy:40
    old "It's kinda cute ngl."
    new "Es bastante cuqui, la verdad."

    # game/days.rpy:89
    old "I don't think you're a loser."
    new "No opino que seas un perdedor."

    # game/days.rpy:93
    old "That dream will become true eventually"
    new "Ese sueño se hará realidad algún día."

    # game/days.rpy:153
    old "I'm kind of busy right now."
    new "Estoy algo ocupadete ahora mismo."

    # game/days.rpy:201
    old "Sweet"
    new "Dulce"

    # game/days.rpy:207
    old "Cringe"
    new "Cringe"

    # game/days.rpy:235
    old "What the FUCK is that??"
    new "¿¿Que COJONES es eso??"

    # game/days.rpy:241
    old "Kinda."
    new "Algo así."

    # game/days.rpy:245
    old "Not quite."
    new "No del todo."

    # game/days.rpy:250
    old "Save some for me."
    new "Guarda un poco para mi."

    # game/days.rpy:270
    old "There's no need to pay."
    new "No es necesario pagar."

    # game/days.rpy:278
    old "I'll take you up on that offer."
    new "Te tomo la palabra."

    # game/days.rpy:328
    old "Are you okay??"
    new "¿¿Estás bien??"

    # game/days.rpy:336
    old "Is that an angel I'm seeing?"
    new "¿Es un ángel eso que veo?"

    # game/days.rpy:344
    old "I was talking bout you. You're pretty."
    new "Hablaba sobre ti. Eres adorable."

    # game/days.rpy:352
    old "Forget it"
    new "Olvidalo."

    # game/days.rpy:355
    old "I'm glad you're fine."
    new "Me alegro de que estés bien."

    # game/days.rpy:360
    old "Holy shit warn a guy before a jumpscare."
    new "Ayer cagué algo parecido."

    # game/days.rpy:367
    old "Whatever."
    new "Lo que sea."

    # game/days.rpy:402
    old "I can't believe I'm going to lose him."
    new "No me puedo creer que vaya a perderle..."

    # game/days.rpy:407
    old "I can't believe I'll be able to pay my debt."
    new "No me puedo creer que vaya a poder pagar mi deuda."

    # game/days.rpy:418
    old "Good morning, honey"
    new "Buenos dias, cariño"

    # game/days.rpy:423
    old "Yes, honey?"
    new "¿Si, cariño?"

    # game/days.rpy:430
    old "Yes."
    new "Si."

    # game/days.rpy:436
    old "Did I made you feel uncomfortable?"
    new "¿Te hice sentir incomodo?"

    # game/days.rpy:444
    old "Good morning"
    new "Buenos dias"

    # game/days.rpy:449
    old "You should be awake by now scum, say good morning."
    new "Deberías estar despierto a estas horas, cacho mierda. Di buenos dias."

    # game/days.rpy:460
    old "Don't worry. We can stay in touch."
    new "No te preocupes. Podemos mantenernos en contacto."

    # game/days.rpy:468
    old "I'll give you my address so you can come to visit."
    new "Te daré mi dirección para que vengas a visitarme."

    # game/days.rpy:478
    old "I really like you too."
    new "Me gustas mucho tu tambien."

    # game/days.rpy:480
    old "Okay, don't worry."
    new "Vale, no te preocupes."

    # game/days.rpy:484
    old "Yeah, me too."
    new "Si, yo también."

    # game/days.rpy:499
    old "There's no point in crying about it."
    new "No tiene sentido lloriquear por eso ahora."

    # game/days.rpy:508
    old "I could never forget you."
    new "Jamás podria olvidarte."

    # game/days.rpy:513
    old "I wont."
    new "No lo haré."

    # game/days.rpy:516
    old "I already did."
    new "Ya lo hice"

