﻿# game/topics.rpy:23
translate spanish talk_random_f202c30e:

    # mf "[renpy.random.choice(lines)][cat]"
    mf "[renpy.random.choice(lines)][cat]"

# game/topics.rpy:43
translate spanish topic_1_862a4091:

    # mf "My butt aches from sitting all day.[cat]"
    mf "Me duele el culo de estar sentado todo el dia.[cat]"

# game/topics.rpy:46
translate spanish topic_1_b4994f21:

    # mf "I-I don't know... Maybe?[cat]"
    mf "N-No se... ¿Tal vez?[cat]"

# game/topics.rpy:49
translate spanish topic_1_dc2e638d:

    # mf "OH MY GOD NO ONE EVER FLIRTED WITH ME LIKE THAT BEFORE!![cat]"
    mf "¡¡AY DIOS MIO NADIE ME HABÍA TIRADO LA CAÑA ASÍ ANTES!![cat]"

# game/topics.rpy:51
translate spanish topic_1_92448279:

    # mf "In fact, no one ever flirted with me.[cat]"
    mf "De hecho nadie me había tirado la caña antes.[cat]"

# game/topics.rpy:59
translate spanish topic_2_2991d4c6:

    # mf "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHH!![cat]"
    mf "¡¡AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHH!![cat]"

# game/topics.rpy:63
translate spanish topic_2_fdbd3186:

    # mf "Just felt like it.[cat]"
    mf "Me ha dado por ahi.[cat]"

# game/topics.rpy:65
translate spanish topic_2_a986fdfb:

    # mf "OH MY GOD IT'S THE FIRST TIME SOMEONE ASKS ME THAT!![cat]"
    mf "¡¡AY DIOS MIO ES LA PRIMERA VEZ QUE ALGUIEN ME PREGUNTA ESO!![cat]"

# game/topics.rpy:67
translate spanish topic_2_4ec28422:

    # mf "Yes, I'm fine![cat]"
    mf "¡Si, estoy bien![cat]"

# game/topics.rpy:76
translate spanish topic_3_2fc795d7:

    # mf "LIFE IS PAIN I HATE-[cat]"
    mf "VIVIR ES SUFIR ODIO-[cat]"

# game/topics.rpy:78
translate spanish topic_3_e352a8f1:

    # mf "Oh, I'm fine now[cat]"
    mf "Oh, ya estoy bien.[cat]"

# game/topics.rpy:87
translate spanish topic_4_df34c6cd:

    # mf "OH MY GOD I'M A FAILURE[cat]"
    mf "AY DIOS SOY UN FRACASADO[cat]"

# game/topics.rpy:90
translate spanish topic_4_ab3e6918:

    # mf "OH MY GOD I AM A LOSER!!!![cat]"
    mf "¡¡¡¡AY DIOS SOY UN PERDEDOR!!!![cat]"

# game/topics.rpy:94
translate spanish topic_4_fb6ccdc1:

    # mf "Oh, I feel a bit better now![cat]"
    mf "¡Oh, me siento algo mejor ahora![cat]"

# game/topics.rpy:102
translate spanish topic_5_a8062627:

    # mf "Will I ever get a girlfriend?[cat]"
    mf "¿Conseguiré novia algún día?[cat]"

# game/topics.rpy:106
translate spanish topic_5_ef43caaa:

    # mf "OH MY GOD YOU'RE RIGHT!!!![cat]"
    mf "¡¡¡¡AY DIOS TIENES TODA LA RAZÓN!!!![cat]"

# game/topics.rpy:107
translate spanish topic_5_619763b2:

    # mf "I'LL DIE ALONE!![cat]"
    mf "¡¡MORIRÉ SOLO!![cat]"

# game/topics.rpy:111
translate spanish topic_5_50809332:

    # mf "Do you really think so?[cat]"
    mf "¿De verdad lo piensas?[cat]"

# game/topics.rpy:112
translate spanish topic_5_4795e5db:

    # mf "That gives me hope![cat]"
    mf "¡Eso me da esperanzas![cat]"

# game/topics.rpy:117
translate spanish topic_5_cec32d29:

    # mf "WHAT???[cat]"
    mf "¿¿¿QUE???[cat]"

# game/topics.rpy:118
translate spanish topic_5_bacb5c5b:

    # mf "IS THIS ONE OF THOSE YAOI GAMES???[cat]"
    mf "¿¿¿ES ESTE UNO DE ESOS JUEGOS YAOI???[cat]"

# game/topics.rpy:120
translate spanish topic_5_576038e9:

    # mf "Well, if I get to NOT DIE ALONE i'll take it.[cat]"
    mf "Bueno, si eso significa que NO MORIRÉ solo lo acepto con gusto.[cat]"

# game/topics.rpy:130
translate spanish topic_6_72dd50f5:

    # mf "Would you still love me if I was a worm, [mc_name]?[cat]"
    mf "¿Me seguirías queriendo si fuese un gusanito de seda, [mc_name]?[cat]"

# game/topics.rpy:136
translate spanish topic_6_8c5d224e:

    # mf "OH MY FUCKING GOD YOU LOVE ME?????[cat]"
    mf "¡¡OSTRAS PEDRÍN!!, ¿¿¿¿¿ME QUIERES?????[cat]"

# game/topics.rpy:138
translate spanish topic_6_a744c27e:

    # mf "I'm so sorry to hear that, honestly[cat]"
    mf "Siento mucho escuchar eso, la verdad.[cat]"

# game/topics.rpy:141
translate spanish topic_6_d2d1f0b1:

    # mf "Thank god... I'd be so sorry for you otherwise.[cat]"
    mf "Menos mal... Lo sentiría mucho si me quisieras.[cat]"

# game/topics.rpy:150
translate spanish topic_7_5cf71a94:

    # mf "Whats 9 plus 10?[cat]"
    mf "¿Cuánto es 9 mas 10?[cat]"

# game/topics.rpy:155
translate spanish topic_7_9cb68428:

    # mf "HOLY SHIT YOU'RE A GENIOUS!!!!!![cat]"
    mf "¡¡¡¡¡¡AHI VA LA HOSTIA ERES UN GENIO!!!!!![cat]"

# game/topics.rpy:157
translate spanish topic_7_25535250:

    # mf "Nope[cat]"
    mf "Nop[cat]"

# game/topics.rpy:160
translate spanish topic_7_a77da3dd:

    # mf "Nice[cat]"
    mf "Nice.[cat]"

# game/topics.rpy:161
translate spanish topic_7_6faec3c0:

    # mf "But nope[cat]"
    mf "Pero nop[cat]"

# game/topics.rpy:169
translate spanish topic_8_33cf197e:

    # mf "What would you do if someone wants to punch you? Not like it happened to me this morning eheh...[cat]"
    mf "¿Que harías si alguien quisiera partirte la cara? No es que me haya pasado esta mañana, ejeje...[cat]"

# game/topics.rpy:174
translate spanish topic_8_67a9ba2e:

    # mf "BUT THAT WOULD HURT MY FIST!!![cat]"
    mf "¡¡¡PERO ME DOLERIA MI PUÑITO!!![cat]"

# game/topics.rpy:176
translate spanish topic_8_5b4d8565:

    # mf "Yeah, same[cat]"
    mf "Ya, yo también.[cat]"

translate spanish strings:

    # game/topics.rpy:45
    old "Should we take you to the gym?"
    new "¿Deberíamos mandate al gimnasio?"

    # game/topics.rpy:47
    old "Sit on my lap instead."
    new "Sientate en mi regazo entonces."

    # game/topics.rpy:61
    old "WHY ARE YOU SCREAMING??"
    new "¿¿POR QUÉ GRITAS??"

    # game/topics.rpy:64
    old "Are you okay?"
    new "¿Estás bien?"

    # game/topics.rpy:89
    old "Only losers think like that."
    new "Solo los perdedores piensan así."

    # game/topics.rpy:92
    old "No, you're not."
    new "No, no lo eres."

    # game/topics.rpy:104
    old "No."
    new "No."

    # game/topics.rpy:115
    old "Maybe a boyfriend..."
    new "Tal vez un novio..."

    # game/topics.rpy:132
    old "Yes, kitten."
    new "Si, gatito."

    # game/topics.rpy:140
    old "WTF? I DON'T LOVE YOU"
    new "¿QUE HOSTIAS? NO TE QUIERO."

    # game/topics.rpy:152
    old "21"
    new "21"

    # game/topics.rpy:156
    old "67"
    new "67"

    # game/topics.rpy:158
    old "69"
    new "69"

    # game/topics.rpy:171
    old "Punch them back"
    new "Darle un puñetazo."

    # game/topics.rpy:175
    old "Cry"
    new "Llorar"

    # game/topics.rpy:16
    old "I'm kinda tired of talking..."
    new "Estoy algo cansadito para hablar..."

    # game/topics.rpy:16
    old "Can we talk more tomorrow?"
    new "¿Podemos hablar más mañana?"

    # game/topics.rpy:16
    old "My social battery is dead..."
    new "Mi batería social ha muerto..."

    # game/topics.rpy:16
    old "We already chatted enough today!!"
    new "¡¡Ya hemos hablado suficiente hoy!!"

