init python:

    config.language = "spanish"